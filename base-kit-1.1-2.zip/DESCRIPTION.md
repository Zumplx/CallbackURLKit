Small businesses are growing fast, highly connected and constantly on-the-go. Their mobile phones have increasingly become one of their biggest business tools; from updating social media, to sending emails and even managing their website.
 
The BaseKit sitebuilder is designed to give your customers an easy way to create a site, blog or online store. All applications are integrated into a single user interface and work seamlessly across any device.


### Designed for the hosting industry
 
Adding value through a sitebuilder can be a genuine game changer within an industry constantly under price pressure. 

**Increase domain renewal:** Offering a simple, powerful and engaging product is proven to increase renewal rates and help boost customer satisfaction.
 
**Brand recognition:** Set yourself apart from competitors with tried, trusted and innovative technology.
 
**Retention:** Increase and influence customer lifetime with 'sticky' value added products.
 
**Growth:** Develop a new revenue stream beyond core services with fresh opportunities and new ways to engage with your small business customers.

 
* *Please note that BaseKit sites are hosted on the BaseKit Cloud, not your hosting infrastructure.*

* *This extension enables you to provide a free 14 day time-limited trial to your customers, with options for them to upgrade to two different paid subscription packages. These paid subscription packages will give full access to the sitebuilder allowing your customers to easily create responsive websites and/or online stores.*