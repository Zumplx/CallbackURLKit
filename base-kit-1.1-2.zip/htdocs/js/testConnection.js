/* 
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     michal.lu@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

function testconnection()
{
    new Ajax.Request('/modules/base-kit/index.php/index/testconnection', {
        method: 'post',
        parameters: $('BaseKitConfigForm').serialize(true),
        onLoading: function () {
            $('test_connection').update('<span class="wait">Please wait</span>');
            $('test_connection').setAttribute('disabled', 'disabled');
            $('config_save').setAttribute('disabled', 'disabled');
        },
        onSuccess: function (response) {
            $('test_connection').update('Test Connection');
            $('test_connection').removeAttribute('disabled', 'disabled');
            $('config_save').removeAttribute('disabled', 'disabled');
            var json = response.responseText.evalJSON();
            if ($('test_connection_msg')) {
                $('test_connection_msg').remove();
            }
            $('main').insert({
                top: '<div id="test_connection_msg" class="msg-box msg-' + json.status + '">' + json.msg + '</div>'
            });

            $('page').scrollTo();
        },
        onFailure: function (response) {
            $('test_connection').update('Test Connection');
            $('test_connection').removeAttribute('disabled');
            $('config_save').removeAttribute('disabled', 'disabled');
            var json = response.responseText.evalJSON();
            if ($('test_connection_msg')) {
                $('test_connection_msg').remove();
            }
            $('main').insert({
                top: '<div id="test_connection_msg" class="msg-box msg-' + json.status + '">' + json.msg + '</div>'
            });
        }

    });
}

$('test_connection').observe('click', function (event) {
    $$('.msg-info').each(Element.hide);
    Event.stop(event);
    testconnection();
});

$('config_save').observe('click', function (event) {
    //$('config_save').update('<span class="wait">Please wait</span>');
    $('BaseKitConfigForm').submit();
    $('test_connection').setAttribute('disabled', 'disabled');
    $('config_save').replace('<button class="btn" disabled><span class="wait">Please wait</span></button>');

});


function addRemoveButtons()
{
    $$('#packages_configuration select').each(function (variable) {
        var name = variable.readAttribute('name');

        var firstUnderscore = name.indexOf('_');
        var lastUnderscore = name.lastIndexOf('_');

        if (firstUnderscore > 0 && lastUnderscore > 0) {
            var packageName = name.substring(firstUnderscore + 1, lastUnderscore);
            variable.insert({'after': '<a href="/modules/base-kit/index.php/index/removePackage/package/' + packageName + '" class="removePackageLink" onclick="return confirm(\'Are you sure you want to remove this package??\')">Remove</a>'})
        }
    });
    //.invoke('insert', {'after' : '<a>Remove</a>'});
}

addRemoveButtons();
