var trialChecked = function(element) {
    var select = element.parentNode.parentNode.getElementsByClassName('addon-td')[0].getElementsByTagName('select')[0];
    select.disabled = element.checked;
};

var appendTooltips = function() {
    var rows = document.getElementsByClassName('form-row');
    var fieldValue;
    
    for(var i = 0 ; i < rows.length ; i++) {
        var node = document.createElement('span');
        
        node.className = 'tooltip';
        node.innerHTML = '(?)';
        
        node.onmouseover = function() {
            
        };
        
        fieldValue = rows[i].getElementsByClassName('field-value');
        
        node.title = fieldValue[0].getElementsByClassName('hint')[0].innerHTML;
        
        fieldValue[0].insertBefore(node, fieldValue[0].getElementsByClassName('field-errors')[0]);
        fieldValue[0].getElementsByClassName('hint')[0].className = 'hint hidden';
    }
};

var planChange = function(element) {
    element.parentNode.parentNode.getElementsByClassName('addon-select')[0].disabled = element.value == '';
};

var disableTestMode = function(element) {
    Jsw.messageBox.show({
        'type': Jsw.messageBox.TYPE_YESNO,
        'subtype': 'delete',
        'text': element.dataset.text,
        'description': element.dataset.description,
        'onYesClick': function() {
            window.location.href = element.href
        },
        'buttonTitles': {
            'yes': element.dataset.yes,
            'no': element.dataset.no                    }
    });

    return false;
};