document.observe('dom:loaded', function () {
    var selectedDomainId = $('mapping_domain').options[$('mapping_domain').selectedIndex].value;
    if ( loginsLinks != null && selectedDomainId != null && loginsLinks[selectedDomainId] != null && $('mapping_login') != null) {
        $('mapping_login').setAttribute('href', loginsLinks[selectedDomainId]);
    }

});

document.observe('change', function (event) {
    var element = event.element();
    if (element.id == 'mapping_domain') {

        var domainId = element.options[element.selectedIndex].value;
        if (loginsLinks != null && selectedDomainId != null && loginsLinks[domainId] != null && $('mapping_login') != null) {
            $('mapping_login').setAttribute('href', loginsLinks[domainId]);
        }
    }
});

document.observe('click', function (event) {
    var element = event.element();
    /*
     if (Element.up(element).id == 'mapping_login' && Event.isLeftClick(event)) {
     Jsw.messageBox.show({
     type: Jsw.messageBox.TYPE_YESNO,
     text: 'Are you sure ?',
     subtype: 'confirm',
     onYesClick: function () {
     window.location.href = "/modules/base-kit/index.php/client/index/index";
     },
     buttonTitles: {
     'yes': 'Yes',
     'no': 'No'
     }
     });
     }
     
     if (Element.up(element).id == 'mapping_map' && Event.isLeftClick(event)) {
     Jsw.messageBox.show({
     type: Jsw.messageBox.TYPE_YESNO,
     text: 'Are you sure ?',
     subtype: 'confirm',
     onYesClick: function () {
     window.location.href = "/modules/base-kit/index.php/client/index/index";
     },
     buttonTitles: {
     'yes': 'Yes',
     'no': 'No'
     }
     });
     }
     */


    if (element.hasClassName('btn') && Event.isLeftClick(event)) {
        if (element.id == 'mapping_map') {

            Jsw.messageBox.show({
                type: Jsw.messageBox.TYPE_YESNO,
                text: 'Warning - mapping this domain to your BaseKit site will stop it being used for any other website it\'s currently associated with.',
                subtype: 'toggle',
                onYesClick: function () {
                    var formData = $('BaseKitMappingForm').serialize(true);
                    delete formData.forgery_protection_token;
                    delete formData.mapping_login;
                    delete formData.mapping_map;
                    formData.module_action = 'map_domain';
                    Jsw.redirectPost('/modules/base-kit/index.php/client/index', formData);
                },
                buttonTitles: {
                    'yes': 'Yes',
                    'no': 'No'
                }
            });
        }

        if (element.id.include('unmap_')) {
            Jsw.messageBox.show({
                type: Jsw.messageBox.TYPE_YESNO,
                text: 'Are you sure you want unmap this domain ?',
                subtype: 'toggle',
                onYesClick: function () {
                    formData = {unmapping_domain: element.id.replace('unmap_', '')};
                    formData.module_action = 'unmap_domain';
                    formData.siteRef = element.getAttribute('data-siteref');
                    formData.domainid = element.getAttribute('data-domainid');
                    Jsw.redirectPost('/modules/base-kit/index.php/client/index', formData);
                },
                buttonTitles: {
                    'yes': 'Yes',
                    'no': 'No'
                }
            });
        }

        if (element.id.include('makeprimary_')) {
            Jsw.messageBox.show({
                type: Jsw.messageBox.TYPE_YESNO,
                text: 'Are you sure you want set this domain as primary ?',
                subtype: 'toggle',
                onYesClick: function () {
                    formData = {makeprimary_domain: element.id.replace('makeprimary_', '')};
                    formData.module_action = 'makeprimary_domain';
                    formData.siteRef = element.getAttribute('data-siteref');
                    Jsw.redirectPost('/modules/base-kit/index.php/client/index', formData);
                },
                buttonTitles: {
                    'yes': 'Yes',
                    'no': 'No'
                }
            });
        }



    }

});
