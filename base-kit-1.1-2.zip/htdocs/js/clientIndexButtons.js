/* 
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     michal.lu@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

document.observe('click', function(event) {
    var element = event.element();
    if(element.hasClassName('btn') && !element.hasClassName('disabled') && Event.isLeftClick(event)){
        if(element.hasClassName('siteRemove')){
            if(!confirm('Achtung:\nDie Löschung kann nachträglich NICHT rückgängig gemacht werden. Fahren Sie nur fort, wenn Sie die komplette Seite neu erstellen möchten.\n\nAttention:\nThis CANNOT be undone and deleted content can never be recovered. Proceed only if you want to create a new site and start again.\n')){
                Event.stop(event);
                return false;
            }
        }
        if(element.hasClassName('loginButton')){
            return false;
        }
        $$('.btn').invoke('addClassName','disabled');
        if(element.nodeName == 'BUTTON'){
            element.update('<span class="wait">Please wait</span>');
        } else {
            element.replace('<button class="btn basekit_domain_login disabled" type="button" name="basekit_domain_login"><span class="wait">Please wait</span></button>');        
        }
    }
});