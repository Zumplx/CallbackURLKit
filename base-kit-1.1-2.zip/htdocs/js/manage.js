/* 
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     michal.lu@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

document.observe('click', function(event) {
    var element = event.element();
    if(element.hasClassName('close') && Event.isLeftClick(event)){
        $('main-disabled-block').hide();
        $('modalDialogBox').hide();
    }
    if(element.hasClassName('btn') && !element.hasClassName('disabled') && !element.hasClassName('customer_domains_showupgrade') && Event.isLeftClick(event)){
        if(element.hasClassName('loginButton')){
            return false;
        }  
        if(element.nodeName == 'BUTTON'){
            if(!element.hasClassName('unmap') && !element.hasClassName('map')){
                $$('.btn').invoke('addClassName','disabled');
                element.update('<span class="wait">Please wait</span>');  
            }          
        } else if (element.nodeName == "A"){
            $$('.btn').invoke('addClassName','disabled');
            element.replace('<button class="btn disabled" type="button" style="margin:20px; pointer-events: none;" name="disabled"><span class="wait">Please wait</span></button>');                     
        } else {
            $$('.btn').invoke('addClassName','disabled');
            element.replace('<button class="btn disabled" type="button" name="disabled" style="pointer-events: none;"><span class="wait">Please wait</span></button>');        
        }
        if(element.hasClassName('unmap')){
            if(confirm('Are you sure you want to unmap this domain?')){
                Event.stop(event);
                $$('.btn').invoke('addClassName','disabled');
                var domainName = element.up('tr').firstDescendant().innerHTML.stripTags();
                new Ajax.Request('/modules/base-kit/index.php/client/unmap', {
                    method: 'post',
                    parameters: {ref: element.getValue(), domainref: $('domainref').getValue(), domainname: domainName},
                    onSuccess: function(response){
                        window.location.reload();
                    },
                    onFailure: function(response){
                        window.location.reload();
                    }

                });
            } else {
                $$('.btn').invoke('removeClassName','disabled');
            }
        } else if(element.hasClassName('makeprimary')){
            Event.stop(event);
            $$('.btn').invoke('addClassName','disabled');
            new Ajax.Request('/modules/base-kit/index.php/client/makeprimary', {
                method: 'post',
                parameters: {ref: element.getValue(), domainref: $('domainref').getValue()},
                onSuccess: function(response){
                    window.location.reload();
                },
                onFailure: function(response){
                    window.location.reload();
                }

            });            
        } else if(element.hasClassName('basekit_domain_login')){
            Event.stop(event);
            $$('.btn').invoke('addClassName','disabled');
            var domainName = $('domainName').innerHTML.stripTags(); 
            new Ajax.Request('/modules/base-kit/index.php/client/login', {
                method: 'post',
                parameters: {domain: domainName},                    
                onSuccess: function(response){
                    var json = response.responseText.evalJSON(); 
                    window.location = json.link;
                },
                onFailure: function(response){
                    window.location.reload();
                }

            });
        }  
    }
});

function formConfirmation(formId){
    if(!confirm('Are you sure you want to map this domain?')){
        $$('.btn').invoke('removeClassName','disabled');  
    } else {
        document.getElementById(formId).submit();
        $('basekit_domain_mapping').update('<span class="wait">Please wait</span>');  
        $$('.btn').invoke('addClassName','disabled');
        return false;
    }    
}
