<?php

class Modules_Basekit_CustomButtons extends pm_Hook_CustomButtons
{

    public function getButtons()
    {
        $session = new \pm_Session();
        $buttonsConfig[] = array(
            'description' => pm_Locale::lmsg('clientarea_module_desc'),
            'place' => array(self::PLACE_ADMIN_HOME),
            'title' => pm_Locale::lmsg('module_name'),
            'icon' => pm_Context::getBaseUrl().'img/basekit.gif',
            'link' => pm_Context::getActionUrl('index/index')
        );

        if ($session->getClient()->isAdmin()) {
            $buttonsConfig[] = array(
                'description' => pm_Locale::lmsg('clientarea_module_desc'),
                'place' => array(self::PLACE_COMMON),
                'title' => pm_Locale::lmsg('module_name'),
                'icon' => pm_Context::getBaseUrl().'img/basekit.gif',
                'link' => pm_Context::getActionUrl('index/index')
            );

//            $buttonsConfig[] = array(
//                'place' => array(self::PLACE_DOMAIN_PROPERTIES),
//                'title' => pm_Locale::lmsg('module_website_name'),
//                'description' => pm_Locale::lmsg('clientarea_module_desc'),
//                'icon' => pm_Context::getBaseUrl().'img/basekit.gif',
//                'link' => pm_Context::getActionUrl('client/index')
//            );
        }


        $customerModel = new Modules_BaseKit_Model_Customers();
        $domainModel = new Modules_BaseKit_Model_Domains();

        if (isset($_SESSION["subscription"]) && !$session->getClient()->isAdmin() && !$session->getClient()->isReseller()) {
            if ($_SESSION["subscription"]["showAll"] === true && isset($_SESSION['auth']['sessionClientId'])) {
                $clientBKSubs = $customerModel->getClientAttachedSubscriptions($_SESSION['auth']['sessionClientId']);
                if (!empty($clientBKSubs)) {
                    $buttonsConfig[] = array(
                        'place' => array(self::PLACE_CUSTOMER_HOME),
                        'title' => pm_Locale::lmsg('module_website_name'),
                        'description' => pm_Locale::lmsg('clientarea_module_desc'),
                        'icon' => pm_Context::getBaseUrl().'img/basekit.gif',
                        'link' => pm_Context::getActionUrl('client/index')
                    );
                    $buttonsConfig[] = array(
                        'place' => array(self::PLACE_DOMAIN),
                        'title' => pm_Locale::lmsg('module_website_name'),
                        'description' => pm_Locale::lmsg('clientarea_module_desc'),
                        'icon' => pm_Context::getBaseUrl().'img/basekit.gif',
                        'link' => pm_Context::getActionUrl('client/index')
                    );
                }
            } else {
                if (isset($_SESSION['auth']['sessionClientId']) && isset($_SESSION["subscription"]["currentId"])) {
                    $subId = $_SESSION["subscription"]["currentId"];
                    $clientBKSubs = $customerModel->getClientAttachedSubscriptions($_SESSION['auth']['sessionClientId']);

                    if (!empty($clientBKSubs) && isset($clientBKSubs[$subId]) && $clientBKSubs[$subId] != "") {
                        $buttonsConfig[] = array(
                            'place' => array(self::PLACE_CUSTOMER_HOME),
                            'title' => pm_Locale::lmsg('module_website_name'),
                            'description' => pm_Locale::lmsg('clientarea_module_desc'),
                            'icon' => pm_Context::getBaseUrl().'img/basekit.gif',
                            'link' => pm_Context::getActionUrl('client/index')
                        );
                        $buttonsConfig[] = array(
                            'place' => array(self::PLACE_DOMAIN),
                            'title' => pm_Locale::lmsg('module_website_name'),
                            'description' => pm_Locale::lmsg('clientarea_module_desc'),
                            'icon' => pm_Context::getBaseUrl().'img/basekit.gif',
                            'link' => pm_Context::getActionUrl('client/index')
                        );
                    }
                }
            }
        }

        return $buttonsConfig;
    }
}