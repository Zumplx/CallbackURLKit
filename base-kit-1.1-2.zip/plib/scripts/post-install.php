<?php

pm_Loader::registerAutoload();
pm_Context::init('base-kit');
pm_Bootstrap::init();

if (!defined('DS')) {
    define('DS', DIRECTORY_SEPARATOR);
}

$dat    = array();
$varDir = pm_Context::getVarDir();
$file   = $varDir.DS.'basekit.ini';

if (file_exists($file)) {
    require_once $file;
}

$sqlite = new Modules_BaseKit_BaseKit_Database();

$sqlite->query("
    CREATE TABLE IF NOT EXISTS `BaseKit_Config` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
        `name` varchar(255) NOT NULL UNIQUE,
        `value` varchar(255)
    );  
");

$sqlite->query("
    CREATE TABLE IF NOT EXISTS `BaseKit_APILogs` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
        `token` varchar(128),
        `apiaction` varchar(128),
        `subscription` varchar(128) DEFAULT NULL,
        `status` varchar(128),
        `debug_data` text,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
");

$sqlite->query("
    CREATE TABLE IF NOT EXISTS `BaseKit_Subscriptions` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
        `plesk_uid` int(128) NOT NULL,
        `bk_uref` int(128) NOT NULL,
        `bk_login` varchar(128),
        `bk_password` varchar(128),
        `plesk_domainid` int(128) DEFAULT NULL,
        `plesk_domainname` varchar(128) DEFAULT NULL,
        `plesk_domainsubid` int(128) NOT NULL,
        `plesk_domainsubname` varchar(128) DEFAULT NULL,
        `bk_packageref` int(128) DEFAULT NULL,
        `siteref` int(128) DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
");
