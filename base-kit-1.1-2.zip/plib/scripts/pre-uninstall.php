<?php

pm_Loader::registerAutoload();
pm_Context::init('base-kit');


if(!defined('DS')) {
    define('DS', DIRECTORY_SEPARATOR);
}

$sqlite = new Modules_BaseKit_BaseKit_Database();
$sqlite->query("DROP TABLE IF EXISTS `BaseKit_Config`;");
$sqlite->query("DROP TABLE IF EXISTS `BaseKit_APILogs`;");