<?php

$os = strtolower(PHP_OS);

if((strpos($os, 'win') !== false && !extension_loaded('pdo_sqlite')
    || strpos($os, 'linux') !== false && !extension_loaded('sqlite3'))) {
    throw new Exception('SQLite extension is required.');
}