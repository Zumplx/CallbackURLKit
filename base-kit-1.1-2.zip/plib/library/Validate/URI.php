<?php

/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     michal.lu@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */
class Modules_BaseKit_Validate_URI extends Zend_Validate_Abstract
{

    protected $_messageTemplates = array(
        'uri' => "This is not valid URL."
    );

    public function isValid($value)
    {
        try {
            $uri = Zend_Uri::factory($value);
            if ($uri->valid()) {
                return true;
            }
        } catch (Zend_Uri_Exception $e) {
            $this->_error('uri');
            return false;
        }
        $this->_error('uri');
        return false;
    }

}
