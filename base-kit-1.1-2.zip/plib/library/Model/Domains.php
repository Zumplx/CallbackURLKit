<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */
class Modules_BaseKit_Model_Domains
{
    protected $db;
    protected $pleskDB;

    public function __construct()
    {
        $this->db = new Modules_BaseKit_BaseKit_Database();
        $this->pleskDB = pm_Bootstrap::getDbAdapter();
    }

    public function pleskDomain($domainid)
    {
        $result = $this->pleskDB->query("SELECT * FROM domains WHERE id=? LIMIT 1", array($domainid))->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function pleskdomains()
    {
        $results = $this->pleskDB->query("SELECT * FROM domains")->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    public function pleskDomainByName($domainName)
    {
        $result = $this->pleskDB->query("SELECT * FROM domains WHERE name=? LIMIT 1", array($domainName))->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function pleskDomainUser($domainid)
    {
        $pleskDomain = $this->pleskDomain($domainid);
        if (isset($pleskDomain['cl_id'])) {
            return (int) $pleskDomain['cl_id'];
        }

        return false;
    }

    public function pleskDomainSubscription($domainid)
    {
        $result = $this->pleskDB->query("SELECT * FROM Subscriptions WHERE object_id=? and object_type='domain' ORDER BY object_id LIMIT 1", array($domainid))->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function pleskDomainSubscriptionId($domainid)
    {
        $domainDetails = $this->pleskDomain($domainid);
        //Jesli jest to addon domena czy subdomena podmieniami idkiem domeny do ktorej nalezy aby pobrac wlasciwe id subskrypcji
        if ((int) $domainDetails['webspace_id'] != 0) {
            $domainid = (int) $domainDetails['webspace_id'];
        }
        $pleskDomainSubscription = $this->pleskDomainSubscription($domainid);
        if (isset($pleskDomainSubscription['id'])) {
            return (int) $pleskDomainSubscription['id'];
        }

        return false;
    }

    public function pleskDomainPlanSubscription($subscriptionid)
    {
        $result = $this->pleskDB->query("SELECT * FROM PlansSubscriptions WHERE subscription_id=? LIMIT 1", array($subscriptionid))->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function pleskDomainPlanSubscriptionId($subscriptionid)
    {
        $pleskDomainPlanSubscription = $this->pleskDomainPlanSubscription($subscriptionid);

        if (isset($pleskDomainPlanSubscription['plan_id'])) {
            return $pleskDomainPlanSubscription['plan_id'];
        }

        return false;
    }

    public function pleskDomainPlan($planid)
    {
        $result = $this->pleskDB->query("SELECT * FROM Templates WHERE id=? LIMIT 1", array($planid))->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getDomainsServicePlans()
    {

        $servicePlans = array();
        $results = $this->pleskDB->query("SELECT * FROM Templates WHERE type='domain'")->fetchAll(PDO::FETCH_ASSOC);
        $customerModel = new Modules_BaseKit_Model_Customers();

        foreach ($results as $servicePlan) {
            if ($servicePlan['name'] != 'Admin Simple') {
                $ownerDetails = $customerModel->getClientDataById($servicePlan['owner_id']);
                $servicePlans[$servicePlan['id']] = $servicePlan['name'].' ( '.$ownerDetails['type'].' '.$ownerDetails['pname'].' )';
            }
        }

        return $servicePlans;
    }

    public function addARecordForDomain($domainId)
    {

        $config = Modules_BaseKit_BaseKit_Config::get();
        $domainDetails = $this->pleskDomain($domainId);
        $IP = $config['config_server_ip'];
        $request = new SimpleXMLElement('<dns></dns>');
        $addRec = $request->addChild('add_rec');
        $addRec->addChild('site-id', $domainId);
        $addRec->addChild('type', 'A');
        $addRec->addChild('host', '');
        $addRec->addChild('value', $IP);
        pm_ApiRpc::getService()->call($request);
        $this->removeARecordForDomain($domainDetails['name'], $this->getDomainAssignedAIPAddress($domainDetails['name']));
        return true;
    }

    /**
     * Removes A record from the domain DNS Zone
     * @param string $domainName
     */
    public function removeARecordForDomain($domainId, $IP = null)
    {
        $config = Modules_BaseKit_BaseKit_Config::get();
        $domainDetails = $this->pleskDomain($domainId);

        if (empty($IP)) {
            $IP = trim($config['config_server_ip']);
        }

        $dnsRecordID = $this->findDNSRecordId($domainDetails['name'].'.', $IP, $domainId);
        if (empty($dnsRecordID)) {
            return false;
        }
        $request = new SimpleXMLElement('<dns></dns>');
        $delRec = $request->addChild('del_rec');
        $delRec->addChild('filter')->addChild('id', $dnsRecordID);
        pm_ApiRpc::getService()->call($request);
        return true;
    }

    private function findDNSRecordId($host, $val, $domainId)
    {
        $queryString = "SELECT dns_recs.id from dns_recs "
            ."LEFT JOIN domains ON domains.dns_zone_id=dns_recs.dns_zone_id "
            ."WHERE dns_recs.type='A' AND dns_recs.host=? AND domains.id=?";
        if (!empty($val)) {
            $queryString .= " AND dns_recs.val=?";
            $result = $this->pleskDB->query($queryString, array($host, $domainId, $val));
        } else {
            $result = $this->pleskDB->query($queryString, array($host, $domainId));
        }
        $data = $result->fetch(PDO::FETCH_ASSOC);
        return $data['id'];
    }

    public function getDomainAssignedAIPAddress($domainName)
    {
        $query = $this->pleskDB->query("SELECT dom.name , ia.ipAddressId, iad.ip_address FROM domains dom "
            ."LEFT JOIN DomainServices d ON (dom.id = d.dom_id AND d.type = 'web') "
            ."LEFT JOIN IpAddressesCollections ia ON ia.ipCollectionId = d.ipCollectionId "
            ."LEFT JOIN IP_Addresses iad ON iad.id = ia.ipAddressId "
            ."WHERE dom.name=?", array($domainName));
        $ips = $query->fetchAll();
        if (!empty($ips)) {
            foreach ($ips as $ip) {
                if (filter_var($ip['ip_address'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false) {
                    return $ip['ip_address'];
                }
            }
        }
        return false;
    }

    public function restoreAssignedIPAAdress($domainId)
    {
        $domainDetails = $this->pleskDomain($domainId);
        $IP = $this->getDomainAssignedAIPAddress($domainDetails['name']);
        $request = new SimpleXMLElement('<dns></dns>');
        $addRec = $request->addChild('add_rec');
        $addRec->addChild('site-id', $domainId);
        $addRec->addChild('type', 'A');
        $addRec->addChild('host', '');
        $addRec->addChild('value', $IP);
        pm_ApiRpc::getService()->call($request);
    }

    public function getSubscriptionDomains($subID)
    {


        $subscription = $this->pleskDB->query("SELECT * FROM Subscriptions WHERE id=? LIMIT 1", array($subID))->fetch(PDO::FETCH_ASSOC);
        $subscriptionDomains[] = $this->pleskDomain($subscription['object_id']);
        $results = $this->pleskDB->query("SELECT * FROM domains WHERE webspace_id=?", array($subscription['object_id']))->fetchAll(PDO::FETCH_ASSOC);

        if(!empty($results)) {
            foreach ($results as $domain) {
                $subscriptionDomains[] = $domain;
            }
        }
        
        return $subscriptionDomains;
    }

    public function domainsToRemoveDNS($plans)
    {
        $clientModel = new Modules_BaseKit_Model_Customers();
        $mappedDomains = $clientModel->getBaseKitSubscriptionUsers();

        $domainsToRemoveDNS = array();
        foreach ($mappedDomains as $mappedDomain) {
            $domainPlanId = $this->pleskDomainPlanSubscriptionId($mappedDomain['plesk_domainsubid']);
            if (in_array($domainPlanId, $plans)) {
                $domainsToRemoveDNS[] = $this->getSubscriptionDomains($mappedDomain['plesk_domainsubid']); //$this->pleskDomain($mappedDomain['plesk_domainid']);
            }
        }

        return $domainsToRemoveDNS;
    }
}