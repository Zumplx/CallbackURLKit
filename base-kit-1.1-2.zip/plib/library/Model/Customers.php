<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */
class Modules_BaseKit_Model_Customers
{
    protected $db;
    protected $pleskDB;

    public function __construct()
    {
        $this->db = new Modules_BaseKit_BaseKit_Database();
        $this->pleskDB = pm_Bootstrap::getDbAdapter();
    }

    /**
     * Returns Plesk Client Data from clients table in database
     * @param int $id - plesk client id
     * @return array
     */
    public function getClientDataById($id)
    {
        $result = $this->pleskDB->query("SELECT * FROM clients WHERE id=? LIMIT 1", array($id))->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    /**
     * Returns BaseKit Subscriptions attached to Plesk Domains
     * @param int $cid - plesk client id
     * @return array
     */
    public function getClientDomainsWithoutSub($cid)
    {
        $domainsWithoutSub = array();
        $results = $this->pleskDB->query("SELECT * FROM domains WHERE cl_id=?", array($cid))->fetchAll(PDO::FETCH_ASSOC);
        foreach ($results as $domain) {
            if ((int) $domain['webspace_id'] == 0) {
                $domainBKSubscriptionAccount = $this->getBaseKitSubscriptionUserByPleskDomainId($domain['id']);
                if (!$domainBKSubscriptionAccount) {
                    $domainsWithoutSub[] = $domain;
                }
            }
        }

        return $domainsWithoutSub;
    }

    /**
     * Returns Plesk Client Data By DomainId
     * @param int $domainId - plesk domain id
     * @return array
     */
    public function getClientDataByDomainId($domainId)
    {
        $result = $this->pleskDB->query("SELECT cl_id FROM domains WHERE id=? LIMIT 1", array($domainId))->fetch(PDO::FETCH_ASSOC);
        $clientId = (int) $result['cl_id'];
        return $this->getClientDataById($clientId);
    }

    /**
     * Returns Plesk Client Data By Email
     * @param int $email - plesk client email
     * @return array
     */
    public function getClientDataByEmail($email)
    {
        $result = $this->pleskDB->query("SELECT * FROM clients WHERE email=? LIMIT 1", array($email))->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    /**
     * Returns Plesk Client Main domain
     * @param int $id - plesk client id
     * @return array
     */
    public function getClientMainDomain($id)
    {
        $request = new SimpleXMLElement('<customer></customer>');
        $getDomain = $request->addChild('get-domain-list');
        $getDomain->addChild('filter')->addChild('id', $id);
        $response = pm_ApiRpc::getService()->call($request);


        if ($response->customer->{'get-domain-list'}->result->status == 'ok') {
            return $response->customer->{'get-domain-list'}->result;
        }
    }

    /**
     * Set Basekit Account
     * @param int $pleskuid - plesk client id
     * @param int $basekituref - basekit account refid
     * @param int $bkLogin - basekit account login
     * @param int $password - basekit account password
     * @param int $domainId - plesk domain id
     * @param int $subId - plesk domain subscription id
     * @return
     */
    public function setBaseKitSubscriptionUser($pleskuid, $basekituref, $bkLogin, $password, $domainId, $subId)
    {

        $customerSubscriptionDetails = $this->getBaseKitSubscriptionUserByPleskSubId($subId);
        $domainModel = new Modules_BaseKit_Model_Domains();

        if (!$customerSubscriptionDetails) {
            $domainDetails = $domainModel->pleskDomain($domainId);
            $domainPlanId = $domainModel->pleskDomainPlanSubscriptionId($subId);
            $plan = $domainModel->pleskDomainPlan($domainPlanId);

            $query = $this->db->prepare("INSERT
                    INTO
                BaseKit_Subscriptions
                    (plesk_uid, bk_uref,bk_login, bk_password,plesk_domainid,plesk_domainname, plesk_domainsubid,plesk_domainsubname)
                VALUES
                    (?, ?, ?, ?, ?, ?, ?, ?);");
            $query->execute(array($pleskuid, $basekituref, $bkLogin, $password, $domainId, $domainDetails['name'], $subId, $plan['name']));
        } else {
            $query = $this->db->prepare("UPDATE
                    BaseKit_Subscriptions
                SET
                    bk_uref=?,bk_login=? ,bk_password=? WHERE plesk_domainsubid=?");
            $query->execute(array($basekituref, $bkLogin, $password, $subId));
        }
    }

    /**
     * Clear SiteRef from BaseKit Accounts
     * @return
     */
    public function removeSiteRef()
    {
        $query = $this->db->prepare("UPDATE BaseKit_Subscriptions SET siteref=null");
        $query->execute();
    }

    /**
     * Delete BaseKit Account by Plesk Client Id
     * @param int $uid - plesk client id
     * @return
     */
    public function deleteBaseKitSubscriptionUser($uid)
    {
        $query = $this->db->prepare("DELETE FROM BaseKit_Subscriptions WHERE plesk_uid=?");
        $query->execute(array($uid));
    }

    /**
     * Get BaseKit Account by Plesk Client Id
     * @param int $pleskuid - plesk client id
     * @return
     */
    public function getBaseKitSubscriptionUserByPleskUID($pleskuid)
    {

        $query = $this->db->prepare("SELECT * FROM BaseKit_Subscriptions WHERE plesk_uid=?");
        $query->execute(array($pleskuid));
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    /**
     * Get BaseKit Account by Plesk Subscription Id
     * @param int $subId - Plesk Subscription Id
     * @return array
     */
    public function getBaseKitSubscriptionUserByPleskSubId($subId)
    {
        $query = $this->db->prepare("SELECT * FROM BaseKit_Subscriptions WHERE plesk_domainsubid=?");
        $query->execute(array($subId));
        $results = $query->fetch(PDO::FETCH_ASSOC);
        return $results;
    }

    /**
     * Get BaseKit Account by Plesk Domain Id
     * @param int $domainId - Plesk Domain Id
     * @return array
     */
    public function getBaseKitSubscriptionUserByPleskDomainId($domainId)
    {
        $query = $this->db->prepare("SELECT * FROM BaseKit_Subscriptions WHERE plesk_domainid=?");
        $query->execute(array($domainId));
        $results = $query->fetch(PDO::FETCH_ASSOC);
        return $results;
    }

    /**
     * Get BaseKit Account by Plesk Domain Id and Client Id
     * @param int $domainId - Plesk Domain Id , int $clientId - Plesk User Id
     * @return array
     */
    public function getBaseKitSubscriptionUserByPleskDomainIdAndUserId($domainId, $clientId)
    {
        $query = $this->db->prepare("SELECT * FROM BaseKit_Subscriptions WHERE plesk_domainid=? and plesk_uid=?");
        $query->execute(array($domainId, $clientId));
        $results = $query->fetch(PDO::FETCH_ASSOC);
        return $results;
    }

    /**
     * Get All BaseKit Accounts
     * @return array
     */
    public function getBaseKitSubscriptionUsers()
    {
        $query = $this->db->prepare("SELECT * FROM BaseKit_Subscriptions");
        $query->execute();
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
        return $results;
    }

    /**
     * Set/update plesk domain id and package(subscription id) to plesk subscription id
     * @param int $domainId - Plesk Domain Id
     * @param int $packageRef - BaseKit package refid
     * @param int $pleskSubId - Plesk subscription id
     * @return array
     */
    public function updateBaseKitSubscription($domainId, $packageRef, $pleskSubId)
    {
        $query = $this->db->prepare("UPDATE BaseKit_Subscriptions SET plesk_domainid =?, bk_packageref=? WHERE plesk_domainsubid=?");
        $query->execute(array($domainId, $packageRef, $pleskSubId));
    }

    /**
     * Remove all BaseKit Accounts
     */
    public function clearBaseKitSubscription()
    {
        $query = $this->db->prepare("Delete from BaseKit_Subscriptions;");
        $query->execute();
    }

    /**
     * Returns Plesk domains for plesk client
     * @param int $cid - plesk client id
     * @return array
     */
    public function getDomains($cid)
    {
        $query = $this->pleskDB->prepare("SELECT * FROM domains WHERE cl_id=?");
        $query->execute(array($cid));
        $response = $query->fetchAll(PDO::FETCH_ASSOC);

        $domains = array();

        foreach ($response as $domain) {
            $domains[$domain['id']] = $domain['name'];
        }

        return $domains;
    }

    /**
     * Returns Plesk domains full Details for plesk client
     * @param int $cid - plesk client id
     * @return array
     */
    public function getDomainsDetails($cid)
    {
        $result   = $this->pleskDB->query("SELECT * FROM domains WHERE cl_id=?", array($cid));
        $response = $result->fetchAll(PDO::FETCH_ASSOC);
        return $response;
    }

    /**
     * Returns BaseKit Logins Links for Plesk Domains
     * @param int $cid - plesk client id
     * @return array
     */
    public function getLoginsLinks($cid, $did)
    {
        $domainModel = new Modules_BaseKit_Model_Domains();
        $clientDomains = $this->getDomains($cid);
        $domainsLoginsLinks = array();
        $subDomains = array();
        $Modules_BaseKit_BKService = new Modules_BaseKit_BKService();
        foreach ($clientDomains as $clientDomainId => $clientDomainName) {
            $domainDetails = $domainModel->pleskDomain($clientDomainId);
            if ((int) $domainDetails['webspace_id'] == 0 && (int) $clientDomainId == (int) $did) {
                $subscriptionId = $domainModel->pleskDomainSubscriptionId($clientDomainId);
                $subscriptionDetails = $this->getBaseKitSubscriptionUserByPleskSubId($subscriptionId);
                $domainsLoginsLinks[$clientDomainId] = $Modules_BaseKit_BKService->getLoginLink($subscriptionDetails['bk_uref']);
            }
        }


        foreach ($clientDomains as $clientDomainId => $clientDomainName) {

            $domainDetails = $domainModel->pleskDomain($clientDomainId);
            if ((int) $domainDetails['webspace_id'] != 0 && (int) $clientDomainId == (int) $did) {
                $domainsLoginsLinks[$clientDomainId] = $domainsLoginsLinks[(int) $domainDetails['webspace_id']];
            }
        }
        return $domainsLoginsLinks;
    }

    /**
     * Set BaseKit siteRef for plesk subscription
     * @param int $pleskSubId - plesk subscription id
     * @param int $siteRef - basekit Site Ref id
     * @return array
     */
    public function setBaseKitSubscriptionUserSiteRef($pleskSubId, $siteRef)
    {
        $query = $this->db->prepare("UPDATE BaseKit_Subscriptions SET siteref=? WHERE plesk_domainsubid=?");
        $query->execute(array($siteRef, $pleskSubId));
    }

    /**
     * Get BaseKit Subscriptions for Plesk Client
     * @param int $cid - plesk client id
     * @return array
     */
    public function getClientAttachedSubscriptions($cid)
    {
        $domainModel = new Modules_BaseKit_Model_Domains();
        $clientModel = new Modules_BaseKit_Model_Customers();

        $results = $this->pleskDB->query("SELECT * FROM domains WHERE cl_id=?", array($cid))->fetchAll(PDO::FETCH_ASSOC);
        $clientAttachedSubs = array();
        $config = Modules_BaseKit_BaseKit_Config::get();

        $clientBKSubAccounts = $clientModel->getBaseKitSubscriptionUserByPleskUID($cid);

        if ($clientBKSubAccounts) {
            foreach ($clientBKSubAccounts as $clientBKSubAccount) {
                $clientAttachedSubs[$clientBKSubAccount['plesk_domainid']] = $clientBKSubAccount['bk_packageref'];
            }
        }

        foreach ($results as $domain) {
            $pleskSubId = $domainModel->pleskDomainSubscriptionId($domain['id']);

            if ($pleskSubId) {
                $pleskSubPlanId = $domainModel->pleskDomainPlanSubscriptionId($pleskSubId);
                if ($pleskSubPlanId && isset($config['config_'.$pleskSubPlanId.'_plan']) && $config['config_'.$pleskSubPlanId.'_plan'] != "" && $config['config_'.$pleskSubPlanId.'_plan'] != null) {
                    $clientAttachedSubs[$domain['id']] = $config['config_'.$pleskSubPlanId.'_plan'];
                }
            }
        }

        return $clientAttachedSubs;
    }

    public function getSubscriptiondomains($subId)
    {
        $subscriptionDomains = array();

        $results = $this->pleskDB->query("SELECT * FROM domains WHERE webspace_id=?", array($subId))->fetchAll(PDO::FETCH_ASSOC);
        foreach ($results as $domain) {
            $subscriptionDomains[$domain['id']] = $domain['name'];
        }

        $result = $this->pleskDB->query("SELECT * FROM domains WHERE id=?", array($subId))->fetch(PDO::FETCH_ASSOC);
        $subscriptionDomains[$result['id']] = $result['name'];
        
        return $subscriptionDomains;
    }

    /**
     * Get Plesk Domains for Plesk Subscription
     * @param int $cid - plesk client id
     * @param int $subId - plesk subscription id
     * @return array
     */
    public function getClientSubscriptionDomains($cid, $subId)
    {
        $domains = array();
        $domainModel = new Modules_BaseKit_Model_Domains();
        $clientDomains = $this->getDomains($cid);

        foreach ($clientDomains as $clientDomainId => $clientDomainName) {
            $clientDomainDetails = $domainModel->pleskDomain($clientDomainId);
            if ((int) $clientDomainDetails['webspace_id'] != 0) {
                $objId = (int) $clientDomainDetails['webspace_id'];
            } elseif ((int) $clientDomainDetails['parentDomainId'] != 0) {
                $objId = (int) $clientDomainDetails['webspace_id'];
            } else {
                $objId = (int) $clientDomainDetails['id'];
            }

            $obgSubId = $domainModel->pleskDomainSubscriptionId($objId);

            if ((int) $obgSubId == (int) $subId) {
                $domains[$clientDomainDetails['id']] = $clientDomainDetails['name'];
            }
        }

        return $domains;
    }

    public function getPleskDomainIdBySiteRef($siteRef)
    {

        $query = $this->db->prepare("SELECT * FROM BaseKit_Subscriptions WHERE siteref=?");
        $query->execute(array($siteRef));
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if (isset($result['plesk_domainid'])) {
            return $result['plesk_domainid'];
        }

        return;
    }

    public function getPleskDomainIdByaccountRef($accountRef)
    {
        $query = $this->db->prepare("SELECT * FROM BaseKit_Subscriptions WHERE bk_uref=?");
        $query->execute(array($accountRef));
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if (isset($result['plesk_domainid'])) {
            return $result['plesk_domainid'];
        }

        return;
    }

    public function deleteBaseKitSubscriptionUserBydidAndcid($cid, $did)
    {
        $query = $this->db->prepare("DELETE FROM BaseKit_Subscriptions WHERE plesk_uid=? and plesk_domainid=?");
        $query->execute(array($cid, $did));
    }
}