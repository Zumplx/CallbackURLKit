<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     michal.lu@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */
class Modules_BaseKit_Model_APILogs
{
    private static $tableName = 'BaseKit_APILogs';

    public static function store($apiAction, $token, $message, $debugData, $status, $pleskSub = array())
    {
        $db = new Modules_BaseKit_BaseKit_Database();
        $session = new pm_Session();
        $serializedDebug = serialize($debugData);
        $userId = $session->getClient()->getId();

        $domainId = "";

        if (!empty($pleskSub) && isset($pleskSub['id']) && $pleskSub['domainId']) {
            if (is_numeric($pleskSub['domainId'])) {
                $domainId = $pleskSub['domainId'];
            } else {
                $domainId = $pleskSub['domainId']." ( ".$pleskSub['id']." )";
            }
        }

        $stmt = $db->prepare("INSERT INTO ".self::$tableName." (token, apiaction, subscription, status, debug_data, created_at) VALUES (?,?,?,?,?,?)");

        $stmt->execute(array($token, $apiAction, $domainId, $status, $serializedDebug, date('Y-m-d h:i:s', time())));
    }

    public static function getAll()
    {
        $db = new Modules_BaseKit_BaseKit_Database();
        $pleskDb = pm_Bootstrap::getDbAdapter();
        $query = $db->prepare("SELECT * FROM ".self::$tableName." ORDER BY ".self::$tableName.".created_at DESC");
        $query->execute();
        $return = $query->fetchAll(PDO::FETCH_ASSOC);
        return $return;
    }

    public static function getLog($token)
    {
        $db = new Modules_BaseKit_BaseKit_Database();
        $query = $db->prepare("SELECT * FROM ".self::$tableName." WHERE token=? LIMIT 1");
        $query->execute(array($token));
        $result = $query->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public static function clear()
    {
        $db = new Modules_BaseKit_BaseKit_Database();
        $query = $db->prepare("DELETE FROM ".self::$tableName);
        $query->execute();
    }
}