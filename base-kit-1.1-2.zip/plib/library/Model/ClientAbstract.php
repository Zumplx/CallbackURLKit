<?php

/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */
abstract class Modules_BaseKit_Model_ClientAbstract
{

    /**
     * Instance of plesk DB adapter
     * @var object
     */
    protected $db;
    protected $pleskDB;
    public $id = null;
    public $parent_id = null;
    public $type = null;
    public $login = null;
    public $cname = null;
    public $pname = null;
    public $email = null;
    public $locale = null;

    protected function populateData($data)
    {
        $this->id = isset($data['id']) ? $data['id'] : $this->id;
        $this->parent_id = isset($data['parent_id']) ? $data['parent_id'] : $this->parent_id;
        $this->type = isset($data['type']) ? $data['type'] : $this->type;
        $this->login = isset($data['login']) ? $data['login'] : $this->login;
        $this->cname = isset($data['cname']) ? $data['cname'] : $this->cname;
        $this->pname = isset($data['pname']) ? $data['pname'] : $this->pname;
        $this->email = isset($data['email']) ? $data['email'] : $this->email;
        $this->locale = isset($data['locale']) ? $this->translateLocaleCode($data['locale']): $this->locale;
        if(empty($this->locale)){
            $this->locale = 'en';
        }
    }
    
    private function translateLocaleCode($pleskCode){
        return substr($pleskCode, 0, 2);
    }
    
}
