<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */
class Modules_BaseKit_Form_Mapping extends Zend_Form
{

    public static function get($vars = null)
    {

        //$clientId = $vars["clientId"];

        $domainsToMapp = array();

        foreach ($vars['clientDomains'] as $clientDomainId => $clientDomainName) {
            $domainIsMapped = false;
            if (isset($vars["mappedDomains"]) && !empty($vars["mappedDomains"])) {
                foreach ($vars["mappedDomains"] as $mappedDomain) {
                    if ($mappedDomain['name'] == $clientDomainName) {
                        $domainIsMapped = true;
                    }
                }
            }

            if (!$domainIsMapped) {
                $domainsToMapp[$clientDomainId] = $clientDomainName;
            }
        }


        if (!empty($domainsToMapp)) {
            $formId = "BaseKitMappingForm";

            $mappingButton = new Zend_Form_Element_Button('mapping_map');
            $mappingButton->setAttrib('id', 'mapping_map');
            $mappingButton->setAttrib('class', 'btn left');
            $mappingButton->setLabel(pm_Locale::lmsg('mapping_map'));
            $mappingButton->setDecorators(array('ViewHelper'));

            $form = new pm_Form_Simple();
            $form->setAttrib('id', $formId);
            $form->setMethod('get');
            $form->addElement('select', 'mapping_domain', array('multiOptions' => $domainsToMapp, 'value' => isset($vars['config_domain']) ? $vars['config_domain'] : ""));
            $form->addElement($mappingButton);

            return $form;
        }

        return false;
    }
}