<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */
class Modules_BaseKit_Form_Configuration extends Zend_Form
{

    public static function get($vars = null)
    {
        $uriValidator = new Modules_BaseKit_Validate_URI();
        $digitsValidator = new Zend_Validate_Digits();
        $alnumValidator = new Zend_Validate_Alnum();
        $emailValidator = new Zend_Validate_EmailAddress();
        $IPValidator = new Zend_Validate_Ip();
        $hostnameValidator = new Zend_Validate_Hostname(array('tld' => false));

        $formId = "BaseKitConfigForm";
        $testConnectionButton = new Zend_Form_Element_Button('config_test_connection');
        $testConnectionButton->setAttrib('id', 'test_connection');
        $testConnectionButton->setAttrib('class', 'btn');
        $testConnectionButton->setLabel(pm_Locale::lmsg('config_test_connection'));
        $testConnectionButton->setDecorators(array('ViewHelper'));
        $domainModel = new Modules_BaseKit_Model_Domains();

        $pleksServicePlans = $domainModel->getDomainsServicePlans(); //Modules_BaseKit_PleskService::getServicePlans();


        $baseKitServicePlans = array('' => 'None');
        $config = Modules_BaseKit_BaseKit_Config::get();
        if ($vars['config_packages']) {
            foreach ($vars['config_packages'] as $package) {
                if ($package['type'] != 'demo') {
                    $baseKitServicePlans[$package['ref']] = $package['name'];
                }
            }
        } else {
            if (!empty($config)) {
                try {

                    $api = new Modules_BaseKit_BaseKit_API($config);
                    $packages = $api->brands()->packages($config['config_brand_ref']);
                    foreach ($packages as $package) {
                        if ($package['productType'] == 'subscription') {
                            $baseKitServicePlans[$package['ref']] = $package['name'];
                        }
                    }
                } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $e) {

                }
            }
        }

        $form = new pm_Form_Simple();
        $form->setAction('/modules/base-kit/index.php/index/configsave');
        $form->setMethod('post')->setAttrib('id', $formId);
        $form->addElement('SimpleText', 'configuration_head', array('label' => pm_Locale::lmsg('configuration_head')));

        if (Modules_BaseKit_PleskService::APIMode() === 'manual') {
            $inputType = 'text';
        } else {
            $inputType = 'hidden';
        }

        //Configuration
        $form->addElement($inputType, 'config_base_url',
                array('label' => pm_Locale::lmsg('config_base_url'),
                'validators' => array($uriValidator), 'required' => true, 'value' => isset($vars['config_base_url']) ? $vars['config_base_url'] : isset($config['config_base_url']) ? $config['config_base_url']
                            : null
                )
            )
            ->addElement($inputType, 'config_base_username',
                array('label' => pm_Locale::lmsg('config_base_username'),
                'required' => true, 'value' => isset($vars['config_base_username']) ? $vars['config_base_username'] : (isset($config['config_base_username']) ? $config['config_base_username']: null)
                )
            )
            ->addElement($inputType, 'config_base_password',
                array('label' => pm_Locale::lmsg('config_base_password'),
                'required' => true, 'value' => isset($vars['config_base_password']) ? $vars['config_base_password'] : (isset($config['config_base_password']) ? $config['config_base_password']: null)
                )
            )
            ->addElement($inputType, 'config_brand_ref',
                array('label' => pm_Locale::lmsg('config_brand_ref'),
                'validators' => array($alnumValidator), 'required' => true, 'value' => isset($vars['config_brand_ref']) ? $vars['config_brand_ref'] : isset($config['config_brand_ref']) ? $config['config_brand_ref']
                            : null
                )
            )
            ->addElement($inputType, 'config_reseller_ref',
                array('label' => pm_Locale::lmsg('config_reseller_ref'),
                'validators' => array($alnumValidator), 'required' => false, 'value' => isset($vars['config_reseller_ref']) ? $vars['config_reseller_ref'] : isset($config['config_reseller_ref']) ? $config['config_reseller_ref']
                            : null
                )
            )
//            ->addElement($inputType, 'config_consumer_key',
//                array('label' => pm_Locale::lmsg('config_consumer_key'),
//                'validators' => array($alnumValidator), 'required' => true, 'value' => isset($vars['config_consumer_key']) ? $vars['config_consumer_key'] : isset($config['config_consumer_key']) ? $config['config_consumer_key']
//                            : null
//                )
//            )
//            ->addElement($inputType, 'config_consumer_secret',
//                array('label' => pm_Locale::lmsg('config_consumer_secret'),
//                'validators' => array($alnumValidator), 'required' => true, 'value' => isset($vars['config_consumer_secret']) ? $vars['config_consumer_secret'] : isset($config['config_consumer_secret'])
//                            ? $config['config_consumer_secret'] : null
//                )
//            )
//            ->addElement($inputType, 'config_access_token',
//                array('label' => pm_Locale::lmsg('config_access_token'),
//                'validators' => array($alnumValidator), 'required' => true, 'value' => isset($vars['config_access_token']) ? $vars['config_access_token'] : isset($config['config_access_token']) ? $config['config_access_token']
//                            : null
//                )
//            )
//            ->addElement($inputType, 'config_access_secret',
//                array('label' => pm_Locale::lmsg('config_access_secret'),
//                'validators' => array($alnumValidator), 'required' => true, 'value' => isset($vars['config_access_secret']) ? $vars['config_access_secret'] : isset($config['config_access_secret']) ? $config['config_access_secret']
//                            : null
//                )
//            )
            ->addElement($inputType, 'config_server_ip',
                array('label' => pm_Locale::lmsg('config_server_ip'),
                'validators' => array($IPValidator), 'required' => true, 'value' => isset($vars['config_server_ip']) ? $vars['config_server_ip'] : isset($config['config_server_ip']) ? $config['config_server_ip']
                            : null
                )
            )
            ->addElement($inputType, 'config_partner_domain',
                array('label' => pm_Locale::lmsg('config_partner_domain'),
                'validators' => array($hostnameValidator), 'required' => true, 'value' => isset($vars['config_partner_domain']) ? $vars['config_partner_domain'] : isset($config['config_partner_domain'])
                            ? $config['config_partner_domain'] : null
                )
        );

        $form->addElement('checkbox', 'config_auto_set_dns',
            array('label' => pm_Locale::lmsg('config_auto_set_dns'),
            'decorators' => array(
                array('Label', array('placement' => 'APPEND', 'tag' => 'div',
                        'class' => 'field-name')),
                array('ViewHelper'),
                array('HtmlTag', array('tag' => 'div', 'class' => 'form-row',
                        'id' => 'config_auto_set_dns-form-row', 'style' => 'margin-top: 3px; margin-bottom: 10px;'))
            ), 'value' => isset($vars['config_auto_set_dns']) ? $vars['config_auto_set_dns'] : null
        ));
        $form->addElement('SimpleText', 'configuration_plans_head', array('label' => pm_Locale::lmsg('configuration_plans_head')));
        $form->addElement('SimpleText', 'configuration_plans_description', array('label' => pm_Locale::lmsg('configuration_plans_description')));

        if ($pleksServicePlans) {
            foreach ($pleksServicePlans as $pleskServicePlanId => $pleskServicePlanName) {
                $form->addElement('select', 'config_'.$pleskServicePlanId.'_plan',
                    array('label' => $pleskServicePlanName, 'multiOptions' => $baseKitServicePlans, 'value' => isset($vars['config_'.$pleskServicePlanId.'_plan']) ? $vars['config_'.$pleskServicePlanId.'_plan']
                            : null));
            }
        }

        $form->addElement('submit', 'config_save', array('class' => 'btn', 'label' => pm_Locale::lmsg('config_save'), 'decorators' => array('ViewHelper')));

        $form->addElements(array($testConnectionButton));

        return $form;
    }
}