<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

class Modules_BaseKit_BaseKit_API
{
    /**
     *
     * @var request[]
     */
    private $_interfaces;
    private $_server;

    public function __construct($config = false)
    {
        if (is_array($config) && !empty($config)) {
            $dataArray = $config;
        }

//        if (empty($dataArray)) {
//            $dataArray = $this->getSettingsFrompmSettings();
//        }
        
        if (empty($dataArray)) {
            $dataArray = $this->getSettingsFromDB();
        }

        $this->_server = new Modules_BaseKit_BaseKit_Server($dataArray);
    }

    private function getSettingsFrompmSettings()
    {
        $configData = pm_Settings::get('BaseKit_Config');
        if (!empty($configData)) {
            $dataArray = unserialize($configData);
            if (is_array($dataArray) && !empty($dataArray)) {
                return $dataArray;
            }
        }
        return array();
    }

    private function getSettingsFromDB()
    {
        $dataArray = Modules_BaseKit_BaseKit_Config::get();
        if (!empty($dataArray) && is_array($dataArray)) {
            return $dataArray;
        }
        return array();
    }

    private function setAPICredentials($dataArray)
    {
        foreach ($dataArray as $name => $value) {
            $camelCased = $this->toCamelCase($name);
            if (property_exists($this, $camelCased)) {
                $this->$camelCased = $value;
            }
        }
    }

    private function _spawnInterface($type)
    {
        $class = 'Modules_BaseKit_BaseKitAPI_'.ucfirst($type);
//        $class = __NAMESPACE__.'\\'.$type;
        $this->_interfaces[$type] = new $class($this->_server);
    }

    /**
     * Load User API 
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @return users
     */
    function users()
    {
        if (empty($this->_interfaces['users'])) {
            $this->_spawnInterface('users');
        }
        return $this->_interfaces['users'];
    }

    /**
     * Load Site API
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @return sites
     */
    function sites()
    {
        if (empty($this->_interfaces['sites'])) {
            $this->_spawnInterface('sites');
        }
        return $this->_interfaces['sites'];
    }

    /**
     * Load Brands API
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @return brands
     */
    function brands()
    {
        if (empty($this->_interfaces['brands'])) {
            $this->_spawnInterface('brands');
        }
        return $this->_interfaces['brands'];
    }

    /**
     * Load Brands API
     *
     * @author Michal Czech <michael@modulesgarden.com>
     * @return brands
     */
    function resellers()
    {
        if (empty($this->_interfaces['resellers'])) {
            $this->_spawnInterface('resellers');
        }
        return $this->_interfaces['resellers'];
    }

    /**
     * Load Brands API
     *
     * @author Michal Czech <michael@modulesgarden.com>
     * @return brands
     */
    function categories()
    {
        if (empty($this->_interfaces['categories'])) {
            $this->_spawnInterface('categories');
        }
        return $this->_interfaces['categories'];
    }

    /**
     * Load Tempaltes API
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @return templates
     */
    function templates()
    {
        if (empty($this->_interfaces['templates'])) {
            $this->_spawnInterface('templates');
        }
        return $this->_interfaces['templates'];
    }
}