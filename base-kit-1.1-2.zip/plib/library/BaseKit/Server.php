<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

class Modules_BaseKit_BaseKit_Server
{

    public $baseUrl;
    public $consumerKey;
    public $consumerSecret;
    public $token;
    public $tokenSecret;
    public $baseUsername;
    public $basePassword;

    public function __construct($dataArray)
    {
        if(!empty($dataArray)){
            foreach ($dataArray as $name => $value) {
                $preparedName = Modules_BaseKit_BaseKit_Config::rmPrefix($name);
                $camelCased = $this->toCamelCase($preparedName);
                if ($camelCased == 'accessToken') {
                    $this->token = $value;
                } elseif ($camelCased == 'accessSecret') {
                    $this->tokenSecret = $value;
                } elseif (property_exists($this, $camelCased)) {
                    $this->{$camelCased} = $value;
                }
            }
        }
    }

    private function toCamelCase($name)
    {
        $string = str_replace(' ', '', ucwords(str_replace('_', ' ', $name)));
        $string[0] = lcfirst($string[0]);
        return $string;
    }

}
