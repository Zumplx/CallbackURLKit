<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

class Modules_BaseKit_BaseKit_Config
{
    static $instance;
    private static $expectedValues = array(
        'config_base_url',
        'config_base_username',
        'config_base_password',
        'config_brand_ref',
        'config_reseller_ref',
        'config_consumer_key',
        'config_consumer_secret',
        'config_access_token',
        'config_access_secret',
        'config_server_ip',
        'config_partner_domain',
        'config_auto_set_dns'
    );
    private static $tableName = 'BaseKit_Config';
    private static $prefix = 'config_';

    private function __construct()
    {

    }

    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new Modules_BaseKit_BaseKit_Config();
            $domainModel = new Modules_BaseKit_Model_Domains();
            $pleksServicePlans = $domainModel->getDomainsServicePlans(); //Modules_BaseKit_PleskService::getServicePlans();
            if (!empty($pleksServicePlans)) {
                foreach ($pleksServicePlans as $pleskServicePlanId => $pleskServicePlanName) {
                    self::$expectedValues[] = self::$prefix.$pleskServicePlanId.'_plan';
                }
            }
        }
        return self::$instance;
    }

    public static function get($name = false, $withPrefix = true)
    {
        $db = new Modules_BaseKit_BaseKit_Database();
        if ($name === false) {
            $query = $db->prepare("SELECT * FROM ".self::$tableName);
            $query->execute();
            $data = $query->fetchAll(PDO::FETCH_ASSOC);

            $configuration = array();
            if (!empty($data)) {
                foreach ($data as $record) {
                    //if (in_array(self::$prefix.$record['name'], self::$expectedValues)) {
                    $key = $withPrefix ? self::$prefix.$record['name'] : $record['name'];
                    $configuration[$key] = $record['value'];
                    //}
                }
            }

            return $configuration;
        } else {
            $query = $db->prepare("SELECT * FROM ".self::$tableName." WHERE name=? LIMIT 1");
            $query->execute(array($name));

            if (!$query) {
                return false;
            }
            $data = $query->fetch(PDO::FETCH_ASSOC);
            return $data['value'];
        }
    }

    public static function rmPrefix($name)
    {
        return str_replace(self::$prefix, '', $name);
    }

    public static function store(array $data)
    {
        $db = new Modules_BaseKit_BaseKit_Database();
        $settingData = array();

        try {
            foreach ($data as $name => $value) {
                if (in_array($name, self::$expectedValues)) {
                    $preparedName = self::rmPrefix($name);
                    $preparedValue = trim($value);

                    $query = $db->prepare("SELECT `id` FROM ".self::$tableName." WHERE `name` = ?");
                    $query->execute(array($preparedName));
                    $select = $query->fetchAll();

                    if ($select && count($select) > 0) {
                        $query = $db->prepare("UPDATE ".self::$tableName." SET `value`=? WHERE `name`=?");
                        $query->execute(array($preparedValue, $preparedName));
                    } else {
                        $query = $db->prepare("INSERT INTO ".self::$tableName." (`name`, `value`) VALUES (?, ?)");
                        $query->execute(array($preparedName, $preparedValue));
                    }


                    $settingData[$preparedName] = $preparedValue;
                }
            }

        } catch (Exception $e) {
            return false;
        }
        return true;
    }
}