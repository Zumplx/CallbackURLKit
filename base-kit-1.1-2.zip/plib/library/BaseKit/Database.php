<?php

class Modules_BaseKit_BaseKit_Database extends PDO
{
    private $dbFile;

    public function __construct($filename = 'sql3db')
    {
        if (!defined('DS')) {
            define('DS', DIRECTORY_SEPARATOR);
        }

        $this->dbFile = sprintf('%s%s.db', pm_Context::getVarDir(), $filename);
        parent::__construct(sprintf('sqlite:%s', $this->dbFile));
    }

    public function destroy()
    {
        if (file_exists($this->dbFile)) {
            unlink($this->dbFile);
        }
    }

    public function prepareAndExec($query, $params = array())
    {
        $stmt = parent::prepare($query);

        if (!$stmt) {
            return false;
        }

        if (!empty($params)) {
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
        }

        return $stmt->execute();
    }

    public function queryAndExecute($query, $params = array())
    {
        $stmt = parent::prepare($query);

        if (!$stmt) {
            return false;
        }

        if (!empty($params)) {
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
        }

        $result = $stmt->execute();

        if ($result) {
            $data = array();
            while ($row  = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $data[] = $row;
            }
        }

        return $data;
    }
}