<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

class Modules_BaseKit_BKService
{

    public function createBaseKitAccount($contactName, $country, $loginName, $email, $clientId, $domainId, $pleskSubId, $customDomainName)
    {
        $password = $this->passwordGenerator();
        $config = Modules_BaseKit_BaseKit_Config::get();
        $lastname = "";
        
        if (strpos($contactName, " ") !== false) {
            list($firstname, $lastname) = explode(' ', $contactName, 2);
        } else {
            $firstname = $contactName;
        }

        if (!isset($lastname) || $lastname == "" || $lastname == null) {
            $lastname = pm_Locale::lmsg('none');
        }

        try {
            $api = new Modules_BaseKit_BaseKit_API($config);
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
            return false;
        }

        try {
            $brandLangs = $api->brands()->getLangs($config['config_brand_ref']);
            $brandLangCode = 'en';

            foreach ($brandLangs as $brandLang) {
                if ($brandLang['code'] === strtolower($country)) {
                    $brandLangCode = $brandLang['code'];
                }
            }
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
            return false;
        }

        $bkcustomer = new Modules_BaseKit_Model_Customers();

        $clientDetails = $bkcustomer->getClientDataById($clientId);

        $newPass = substr(md5(time() * rand(0, 1000)), 0, 8);
        $shuffled = str_shuffle('abcdefghijklmnopqrstuvxyzABCDEFGHIJKLMNOPQRSTUVXYZ');
        $newLogin = substr($shuffled, 0, 6);
        $newEmail = $clientDetails['login'].'@'.$customDomainName;

        $pleskSub = array('id' => $pleskSubId, 'domainId' => $domainId);
        try {
            $createBrandUserResponse = $api->users()->create($config['config_brand_ref'], $firstname, $lastname, $newLogin, $newPass, $newEmail, $brandLangCode, $config['config_reseller_ref'],
                $pleskSub);
            $clientBKRef = $createBrandUserResponse['ref'];
            $bkcustomer->setBaseKitSubscriptionUser($clientId, $clientBKRef, $newLogin, $newPass, $domainId, $pleskSubId);
        } catch (\Exception $ex) {
            if ($ex->getMessage() == "Validation failed: Username already exists, Email address already exists") {
                $clientBKRef = false;
                $offset = 0;
                do {
                    $bkUsers = $api->users()->lists(20, $offset);
                    foreach ($bkUsers as $bkUser) {
                        if ($bkUser['email'] == $email) {
                            $clientBKRef = $bkUser["ref"];
                        }
                    }
                    $offset = $offset + 20;
                } while (!empty($bkUsers) && $clientBKRef === false);
                if ($clientBKRef !== false) {
                    $response = $api->users()->edit($clientBKRef, $firstname, $lastname, $newLogin, $newPass, $newEmail, $brandLangCode, $config['config_reseller_ref'], $pleskSub);
                    $bkcustomer->setBaseKitSubscriptionUser($clientId, $clientBKRef, $newLogin, $newPass, $domainId, $pleskSubId);
                }
            }
        }
    }

    public function deleteBaseKitSubscription($domainId)
    {
        $customerModel = new Modules_BaseKit_Model_Customers();
        $domainModel = new Modules_BaseKit_Model_Domains();
        $client = $customerModel->getClientDataByDomainId($domainId);
        $bkAccount = $customerModel->getBaseKitSubscriptionUserByPleskDomainIdAndUserId($domainId, $client['id']);

        $config = Modules_BaseKit_BaseKit_Config::get();
        try {
            $api = new Modules_BaseKit_BaseKit_API($config);
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
            return false;
        }

        $pleskSub = array('id' => $bkAccount['plesk_domainsubname'], 'domainId' => $bkAccount['plesk_domainname']);
        try {
            if (isset($bkAccount['siteref']) && $bkAccount['siteref'] != "" && $bkAccount['siteref'] != null) {
                $deleteBKSiteResponse = $api->sites()->remove($bkAccount['siteref'], $pleskSub);
            }
            $deleteBKUserResponse = $api->users()->remove($bkAccount['bk_uref'], $pleskSub);
            $customerModel->deleteBaseKitSubscriptionUserBydidAndcid($bkAccount['plesk_uid'], $bkAccount['plesk_domainid']);
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {

        }
    }

    public function deleteBaseKitAccount()
    {
        $customerModel = new Modules_BaseKit_Model_Customers();
        $bkUsers = $customerModel->getBaseKitSubscriptionUsers();
        $config = Modules_BaseKit_BaseKit_Config::get();
        try {
            $api = new Modules_BaseKit_BaseKit_API($config);
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
            return false;
        }

        foreach ($bkUsers as $bkUser) {
            if (!$customerModel->getClientDataById($bkUser['plesk_uid'])) {
                $pleskSub = array('id' => $bkUser['plesk_domainsubname'], 'domainId' => $bkUser['plesk_domainname']);
                try {
                    if (isset($bkUser['siteref']) && $bkUser['siteref'] != "" && $bkUser['siteref'] != null) {
                        $deleteBKSiteResponse = $api->sites()->remove($bkUser['siteref'], $pleskSub);
                    }
                    $deleteBKUserResponse = $api->users()->remove($bkUser['bk_uref'], $pleskSub);
                    $customerModel->deleteBaseKitSubscriptionUser($bkUser['plesk_uid']);
                } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {

                }
            }
        }
    }

    public function deleteBaseKitAccounts()
    {
        $customerModel = new Modules_BaseKit_Model_Customers();
        $bkUsers = $customerModel->getBaseKitSubscriptionUsers();
        $config = Modules_BaseKit_BaseKit_Config::get();
        try {
            $api = new Modules_BaseKit_BaseKit_API($config);
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
            return false;
        }

        foreach ($bkUsers as $bkUser) {
            if ($customerModel->getClientDataById($bkUser['plesk_uid'])) {
                $pleskSub = array('id' => $bkUser['plesk_domainsubname'], 'domainId' => $bkUser['plesk_domainname']);
                try {
                    if (isset($bkUser['siteref']) && $bkUser['siteref'] != "" && $bkUser['siteref'] != null) {
                        $deleteBKSiteResponse = $api->sites()->remove($bkUser['siteref'], $pleskSub);
                    }
                    $deleteBKUserResponse = $api->users()->remove($bkUser['bk_uref'], $pleskSub);
                    $customerModel->deleteBaseKitSubscriptionUser($bkUser['plesk_uid']);
                } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {

                }
            }
        }
    }

    public function addBaseKitUserPackage($domainId)
    {
        $domainModel = new Modules_BaseKit_Model_Domains();
        $clientModel = new Modules_BaseKit_Model_Customers();
        $config = Modules_BaseKit_BaseKit_Config::get();

        $domainUserId = $domainModel->pleskDomainUser($domainId);
        $domainDetails = $domainModel->pleskDomain($domainId);

        $partnerDomain = $config['config_partner_domain'];
        $clientDetails = $clientModel->getClientDataById($domainUserId);
        
        $domainModel->removeARecordForDomain($domainId);

        if ($clientDetails['type'] != 'client') {
            return;
        }

        $customDomainName = strtolower(preg_replace("/[^A-Za-z0-9 ]/", '', $clientDetails['login']).'-'.time().'.'.$partnerDomain);

        if ($domainUserId) {

            //Return plesk Subscription id or false
            $domainSubscriptionId = ((int) $domainDetails['webspace_id'] != 0) ? (int) $domainDetails['webspace_id'] : $domainModel->pleskDomainSubscriptionId($domainId);
            if ($domainSubscriptionId) {

                $customerDetails = $clientModel->getBaseKitSubscriptionUserByPleskSubId($domainSubscriptionId);
                //Return plesk Plan id
                $domainPlanSubscriptionId = $domainModel->pleskDomainPlanSubscriptionId($domainSubscriptionId);
                if ($domainPlanSubscriptionId) {
                    if (
                        isset($config['config_'.$domainPlanSubscriptionId.'_plan']) &&
                        $config['config_'.$domainPlanSubscriptionId.'_plan'] != "" &&
                        $config['config_'.$domainPlanSubscriptionId.'_plan'] != null
                    ) {
                        $packageRef = $config['config_'.$domainPlanSubscriptionId.'_plan'];


                        //If BaseKit User Ref Not Exist we need Create It First
                        $bkUserExist = true;
                        if (!isset($customerDetails['bk_uref']) || $customerDetails['bk_uref'] == "" || $customerDetails['bk_uref'] == null) {
                            $bkUserExist = false;
                            $domainUserDetails = $clientModel->getClientDataById($domainUserId);
                            $this->createBaseKitAccount(
                                $domainUserDetails['pname'], $domainUserDetails['country'], $domainUserDetails['login'], $domainUserDetails['email'], $domainUserId, $domainId, $domainSubscriptionId,
                                $customDomainName
                            );
                            $customerDetails = $clientModel->getBaseKitSubscriptionUserByPleskSubId($domainSubscriptionId);
                        }

                        $pleskSub = array('id' => $domainSubscriptionId, 'domainId' => $domainId);
                        try {
                            $api = new Modules_BaseKit_BaseKit_API($config);
                            $addUserPackageResponse = $api->users()->addPackage($customerDetails['bk_uref'], $packageRef, null, $pleskSub);
                            $clientModel->updateBaseKitSubscription($domainId, $packageRef, $domainSubscriptionId);
                            //Create Site Only when user has been first time created
                            if (!$bkUserExist) {
                                $this->mapDomain($domainUserId, $domainId, $customDomainName);
                            }
                        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
                            
                        }
                    }
                }
            }
        }
    }

    public function updateBaseKitUserPackage($domainId)
    {
        sleep(5);
        //This will also update BaseKit User Package read http://apidocs.basekit.com/api-reference/users/#create-user-package
        $this->addBaseKitUserPackage($domainId);
    }

    public function getClientPackageRef($cid)
    {
        $clientModel = new Modules_BaseKit_Model_Customers();
        $mainDomainId = $this->getClientMainDomainId($cid);

        $domain = new Modules_BaseKit_Model_Domains();
        $domainsubscription = $domain->pleskDomainSubscription($mainDomainId);
        $domainPlanSubscription = $domain->pleskDomainPlanSubscription($domainsubscription['id']);
        $config = Modules_BaseKit_BaseKit_Config::get();
        $packageRef = $config['config_'.$domainPlanSubscription['plan_id'].'_plan'];

        return (int) $packageRef;
    }

    public function getClientMainDomainId($cid)
    {
        $clientModel = new Modules_BaseKit_Model_Customers();
        $clientDomains = $clientModel->getClientMainDomain($cid);

        $mainDomainId = null;
        foreach ($clientDomains->domains as $clientDomain) {
            if ($clientDomain->domain->main == true) {
                $mainDomainId = (int) $clientDomain->domain->id;
            }
        }

        return $mainDomainId;
    }

    public function mapDomain($cid, $did, $customdomainName = null)
    {
        $domainModel = new Modules_BaseKit_Model_Domains();
        $clientModel = new Modules_BaseKit_Model_Customers();

        $recivedDoaminClientId = $domainModel->pleskDomainUser($did);

        $session = new \pm_Session();

        if ((int) $recivedDoaminClientId != (int) $cid && !$session->getClient()->isAdmin() && !$session->getClient()->isReseller()) {
            return pm_Locale::lmsg('map_user_error');
        }

        $domainDetails = $domainModel->pleskDomain($did);
        $config = Modules_BaseKit_BaseKit_Config::get();
        $domainSubSiteData = $this->getBaseKitDomainSubscriptionSiteData($did);

        $domainSubId = $domainModel->pleskDomainSubscriptionId($did);

        $clientSubscritionUser = $clientModel->getBaseKitSubscriptionUserByPleskSubId($domainSubId);

        try {
            $api = new Modules_BaseKit_BaseKit_API($config);
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
            return $ex->getMessage();
        }

        if (isset($_SESSION["subscription"]["currentId"])) {
            $domainsSubId = $domainModel->pleskDomainSubscriptionId($_SESSION["subscription"]["currentId"]);
            $pleskSub = array('id' => $domainsSubId, 'domainId' => $_SESSION["subscription"]["currentId"]);
        } else {
            $pleskSub = array('id' => $domainSubId, 'domainId' => $did);
        }

        if (!$domainSubSiteData) {
            try {
                $siteDomain = $domainDetails['name'];
                if ($customdomainName != null) {
                    $siteDomain = $customdomainName;
                }

                $createSiteResponse = $api->sites()->create($config['config_brand_ref'], $clientSubscritionUser['bk_uref'], $siteDomain, null, 'responsive', 'inactive', $pleskSub);
            } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
                return $ex->getMessage();
            }

            if (isset($createSiteResponse['ref'])) {
                if ((int) $config['config_auto_set_dns'] == 1) {
                    $domainModel->addARecordForDomain($did);
                }
                $clientModel->setBaseKitSubscriptionUserSiteRef($domainSubId, $createSiteResponse['ref']);
            }
        } else if (isset($domainSubSiteData['ref'])) {
            try {
                $mapdomainResponse = $api->sites()->mapDomain($domainSubSiteData['ref'], $domainDetails['name'], $pleskSub);
                if ((int) $config['config_auto_set_dns'] == 1) {
                    $domainModel->addARecordForDomain($did);
                }
            } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {

                if ($ex->getMessage() == "Validation failed: Domain is already in use") {
                    $bkSites = $api->sites()->lists($config["config_brand_ref"], array('domain' => $domainDetails['name']));

                    if (isset($bkSites['sites'])) {
                        foreach ($bkSites['sites'] as $site) {
                            foreach ($site['domains'] as $siteDomainId => $siteDomainName) {
                                if ($siteDomainName == $domainDetails['name']) {
                                    $this->unmapDomain($cid, $siteDomainId, $site['ref'], $did);
                                }
                            }
                        }
                    }
                }

                return $ex->getMessage();
            }
        } elseif (is_string($domainSubSiteData)) {
            return $domainSubSiteData;
        }

        return true;
    }

    public function unmapDomain($cid, $domainRef, $siteRef, $did)
    {
        $config = Modules_BaseKit_BaseKit_Config::get();
        $domainModel = new Modules_BaseKit_Model_Domains();
        $domainSubId = $domainModel->pleskDomainSubscriptionId($did);
        $clientCurrentSubId = $domainModel->pleskDomainSubscriptionId($_SESSION["subscription"]["currentId"]);
        $domainSubSiteData = $this->getBaseKitSubscriptionSiteData($siteRef);

        $clinetMappedDomains = $this->getClientSubscriptionMappedDomains($cid, $_SESSION["subscription"]["currentId"]);

        $mappedDomainValidate = false;
        foreach ($clinetMappedDomains as $mappedDomain) {
            if ((int) $mappedDomain["pleskdomainid"] == (int) $did && (int) $mappedDomain["siteref"] == (int) $siteRef) {
                $mappedDomainValidate = true;
                break;
            }
        }

        if (!$mappedDomainValidate) {
            return pm_Locale::lmsg('unmap_user_error');
        }

        $pleskSub = array('id' => $clientCurrentSubId, 'domainId' => $_SESSION["subscription"]["currentId"]);

        try {
            $api = new Modules_BaseKit_BaseKit_API($config);
            $api->sites()->unMapDomain($domainSubSiteData['ref'], $domainRef, $pleskSub);
            if ((int) $config['config_auto_set_dns'] == 1) {
                $domainModel->removeARecordForDomain($did);
                $domainModel->restoreAssignedIPAAdress($did);
            }
            return true;
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
            return $ex->getMessage();
        }
    }

    public function makePrimaryDomain($cid, $domainRef, $siteRef)
    {
        $config = Modules_BaseKit_BaseKit_Config::get();
        $clientModel = new Modules_BaseKit_Model_Customers();
        $domainModel = new Modules_BaseKit_Model_Domains();


        $domainId = $clientModel->getPleskDomainIdBySiteRef($siteRef);
        $domainUserId = $domainModel->pleskDomainUser($domainId);

        if ((int) $domainUserId != (int) $cid) {
            return pm_Locale::lmsg('makeprimary_user_error');
        }

        $domainSubId = $domainModel->pleskDomainSubscriptionId($domainId);

        $pleskSub = array('id' => $domainSubId, 'domainId' => $domainId);
        try {
            $api = new Modules_BaseKit_BaseKit_API($config);
            $updateResponse = $api->sites()->update($siteRef, null, null, $domainRef, null, $pleskSub);
            return true;
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
            return $ex->getMessage();
        }
    }

    public function getBaseKitDomainSubscriptionSiteData($did)
    {
        $domainModel = new Modules_BaseKit_Model_Domains();
        $clientModel = new Modules_BaseKit_Model_Customers();

        if (isset($_SESSION["subscription"]["currentId"]) && $_SESSION["subscription"]["currentId"] != "" && $_SESSION["subscription"]["currentId"] != null) {
            $clientSubId = $domainModel->pleskDomainSubscriptionId($_SESSION["subscription"]["currentId"]);
        } else {
            $clientSubId = $domainModel->pleskDomainSubscriptionId($did);
        }


        $domainSubId = $domainModel->pleskDomainSubscriptionId($did);

        if (isset($_SESSION["subscription"]["currentId"]) && $_SESSION["subscription"]["currentId"] != "" && $_SESSION["subscription"]["currentId"] != null) {
            $pleskSub = array('id' => $clientSubId, 'domainId' => $_SESSION["subscription"]["currentId"]);
        } else {
            $pleskSub = array('id' => $clientSubId, 'domainId' => $did);
        }

        $clientSubscritionUser = $clientModel->getBaseKitSubscriptionUserByPleskSubId($domainSubId);

        if ($clientSubscritionUser['siteref'] != null && $clientSubscritionUser['siteref'] != "") {
            $config = Modules_BaseKit_BaseKit_Config::get();
            try {
                $api = new Modules_BaseKit_BaseKit_API($config);
                $domainSubscriptionSiteResponse = $api->sites()->get($clientSubscritionUser['siteref'], $pleskSub);
                return $domainSubscriptionSiteResponse;
            } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
                return $ex->getMessage();
            }
        }

        return false;
    }

    public function getBaseKitSubscriptionSiteData($siteRef)
    {
        $config = Modules_BaseKit_BaseKit_Config::get();
        try {
            $api = new Modules_BaseKit_BaseKit_API($config);
            $domainSubscriptionSiteResponse = $api->sites()->get($siteRef);
            return $domainSubscriptionSiteResponse;
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
            return $ex->getMessage();
        }
    }

    public function getClientMappedDomains($cid)
    {
        $clientModel = new Modules_BaseKit_Model_Customers();
        $domainModel = new Modules_BaseKit_Model_Domains();
        $clietDomains = $clientModel->getDomainsDetails($cid);

        $mappedDomains = array();

        foreach ($clietDomains as $clietDomain) {
            if ((int) $clietDomain['webspace_id'] == 0) {
                $domainSubSiteData = $this->getBaseKitDomainSubscriptionSiteData($clietDomain['id']);
                if ($domainSubSiteData && isset($domainSubSiteData['domains'])) {
                    foreach ($domainSubSiteData['domains'] as $siteDomainId => $siteDomainName) {
                        $mappedDomains[] = [
                            'domainref' => $siteDomainId,
                            'name' => $siteDomainName,
                            'primary' => ((int) $siteDomainId == (int) $domainSubSiteData['primaryDomain']['ref']) ? 1 : 0,
                            'siteref' => $domainSubSiteData['ref']
                        ];
                    }
                }
            }
        }

        return $mappedDomains;
    }

    public function getClientSubscriptionMappedDomains($cid, $did)
    {
        $clientModel = new Modules_BaseKit_Model_Customers();
        $domainModel = new Modules_BaseKit_Model_Domains();
        $clietDomainDetails = $domainModel->pleskDomain($did);
        $mappedDomains = array();

        if ((int) $clietDomainDetails['webspace_id'] == 0) {
            $domainSubSiteData = $this->getBaseKitDomainSubscriptionSiteData($clietDomainDetails['id']);
            if ($domainSubSiteData && isset($domainSubSiteData['domains'])) {
                foreach ($domainSubSiteData['domains'] as $siteDomainId => $siteDomainName) {
                    $domainDetails = $domainModel->pleskDomainByName($siteDomainName);
                    $mappedDomains[] = [
                        'domainref' => $siteDomainId,
                        'name' => $siteDomainName,
                        'primary' => ((int) $siteDomainId == (int) $domainSubSiteData['primaryDomain']['ref']) ? 1 : 0,
                        'siteref' => $domainSubSiteData['ref'],
                        'pleskdomainid' => isset($domainDetails['id']) ? $domainDetails['id'] : ""
                    ];
                }
            }

            if (is_string($domainSubSiteData)) {
                return $domainSubSiteData;
            }
        }

        return $mappedDomains;
    }

    public function deleteSitesWithPleskDomans()
    {
        $config = Modules_BaseKit_BaseKit_Config::get();
        $domainModel = new Modules_BaseKit_Model_Domains();
        $clientModel = new Modules_BaseKit_Model_Customers();
        $clientModel->removeSiteRef();
        $pleskDomains = $domainModel->pleskdomains();
        $api = new Modules_BaseKit_BaseKit_API($config);

        foreach ($pleskDomains as $pleskDomain) {
            $bkSites = $api->sites()->lists($config["config_brand_ref"], array('domain' => $pleskDomain['name']));

            if (isset($bkSites['sites'])) {
                foreach ($bkSites['sites'] as $site) {
                    foreach ($site['domains'] as $siteDomainId => $siteDomainName) {
                        if ($siteDomainName == $pleskDomain['name']) {
                            $api->sites()->remove($site['ref']);
                        }
                    }
                }
            }
        }
    }

    public function getLoginLink($accountRef)
    {
        $config = Modules_BaseKit_BaseKit_Config::get();
        $domainModel = new Modules_BaseKit_Model_Domains();
        $clientModel = new Modules_BaseKit_Model_Customers();
        $domainId = $clientModel->getPleskDomainIdByaccountRef($accountRef);

        $domainSubId = $domainModel->pleskDomainSubscriptionId($domainId);
        $pleskSub = array('id' => $domainSubId, 'domainId' => $domainId);
        try {
            $api = new Modules_BaseKit_BaseKit_API($config);
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {
            return false;
        }
        $url = $config['config_base_url'];

        list($junk, $loginUrl) = explode("rest.", $url);

        try {
            $result = 'http://flow.'.$loginUrl."/login?hash=".$api->users()->autoLoginHash($accountRef, $pleskSub);
            return $result;
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $ex) {

        }

        return false;
    }

    private function passwordGenerator()
    {
        $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < 16; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }

    public function log($data)
    {
        Modules_BaseKit_Model_APILogs::store('bkservice', md5(microtime()), 'BKService Log', $data, 'Success');
    }
}