<?php
class Modules_BaseKit_Exceptions_BaseKitLib extends Modules_BaseKit_Exceptions_Base
{
    private $debugData;

    /**
     *
     * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
     * @param string $message
     * @param array $debugData
     */
    function __construct($message, $code,$debugData = array()) {
        parent::__construct($message, $code);
        $this->debugData = $debugData;
        Modules_BaseKit_Model_APILogs::store($this->getToken(), $this->getMessage(), $this->getTrace());
    }
}