<?php

pm_Loader::registerAutoload();

require 'vendor/autoload.php';

class Modules_BaseKit_EventListener
{

    public function handleEvent($objectType, $objectId, $action, $oldValues, $newValues)
    {
        pm_Context::init('base-kit');
        pm_Bootstrap::init();

        $data = array(
            'action' => $action,
            'objectType' => $objectType,
            'objectId' => $objectId,
            'oldValues' => $oldValues,
            'newValues' => $newValues
        );

        //Modules_BaseKit_BKService::log($data);
        $customerModel = new Modules_BaseKit_Model_Customers();
        $Modules_BaseKit_BKService = new Modules_BaseKit_BKService();

        switch ($action) {
            case "phys_hosting_create":
                $Modules_BaseKit_BKService->addBaseKitUserPackage($objectId);
                break;
            case "phys_hosting_delete":
                $Modules_BaseKit_BKService->deleteBaseKitSubscription($objectId);
                break;
            case "domain_limits_update":
                if (Modules_BaseKit_PleskService::isPlesk12()) {
                    $Modules_BaseKit_BKService->updateBaseKitUserPackage($objectId);
                }
                break;
            case "domain_plan_change":
                if (Modules_BaseKit_PleskService::isPlesk17()) {
                    $Modules_BaseKit_BKService->updateBaseKitUserPackage($objectId);
                }
                break;
            case "client_delete":
                $Modules_BaseKit_BKService->deleteBaseKitAccount();
                break;
        }
    }
}
return new Modules_BaseKit_EventListener();
