<?php

class Modules_BaseKit_PleskService
{

    public static function getServicePlans($excludedServicePlans = array())
    {
        $request = <<< EOT
            <service-plan>
                <get>
                    <filter/>
                </get>
            </service-plan>
EOT;
        $response = pm_ApiRpc::getService()->call($request);

        $skipServicePlans = array_merge($excludedServicePlans, array('Admin Simple'));

        if (isset($response->{'service-plan'}->get)) {
            $result = $response->{'service-plan'}->get;

            $servicePlans = array();
            foreach ($result->result as $servicePlan) {
                $planName = $servicePlan->name->__toString();

                if (in_array($planName, $skipServicePlans)) {
                    continue;
                }

                $servicePlans[$servicePlan->id->__toString()] = $planName;
            }
        }

        return $servicePlans;
    }

    public static function getKAApiDetails()
    {
        $details = pm_License::getAdditionalKeysList('ext-base-kit'); //self::fakeExtBaseKitKABody();
        $details = (count($details) != count($details, 1)) ? reset($details) : $details;

        $keyBody = isset($details['key-body']) ? $details['key-body'] : null;

        $expectedValues = [
            'apiUrl',
            'brandRef',
            'consumerKey',
            'consumerSecret',
            'accessToken',
            'accessSecret',
            'environmentIpAddress',
            'publishedSitesDomain',
        ];

        $results = array();
        $results['keybodyempty'] = true;

        if (!empty($keyBody)) {
            $results['keybodyempty'] = false;
            $ApiDetails = json_decode($keyBody, true);

            foreach ($expectedValues as $expectedValue) {
                if (!array_key_exists($expectedValue, $ApiDetails) || ( array_key_exists($expectedValue, $ApiDetails) && ($ApiDetails[$expectedValue] === null || $ApiDetails[$expectedValue] === ""))) {
                    $results['missing_params'][] = $expectedValue;
                }
            }
        }
        $results['config_packages'] = isset($ApiDetails['packages']) ? $ApiDetails['packages'] : "";
        $results['config_base_url'] = isset($ApiDetails['apiUrl']) ? $ApiDetails['apiUrl'] : "";
        $results['config_brand_ref'] = isset($ApiDetails['brandRef']) ? $ApiDetails['brandRef'] : "";
        $results['config_reseller_ref'] = isset($ApiDetails['resellerRef']) ? $ApiDetails['resellerRef'] : "";
        $results['config_consumer_key'] = isset($ApiDetails['consumerKey']) ? $ApiDetails['consumerKey'] : "";
        $results['config_consumer_secret'] = isset($ApiDetails['consumerSecret']) ? $ApiDetails['consumerSecret'] : "";
        $results['config_access_token'] = isset($ApiDetails['accessToken']) ? $ApiDetails['accessToken'] : "";
        $results['config_access_secret'] = isset($ApiDetails['accessSecret']) ? $ApiDetails['accessSecret'] : "";
        $results['config_server_ip'] = isset($ApiDetails['environmentIpAddress']) ? $ApiDetails['environmentIpAddress'] : "";
        $results['config_partner_domain'] = isset($ApiDetails['publishedSitesDomain']) ? $ApiDetails['publishedSitesDomain'] : "";
        $results['config_base_username'] = isset($ApiDetails['basicAuthUsername']) ? $ApiDetails['basicAuthUsername'] : "";
        $results['config_base_password'] = isset($ApiDetails['basicAuthPassword']) ? $ApiDetails['basicAuthPassword'] : "";


        $configuration = Modules_BaseKit_BaseKit_Config::getInstance();
        $configuration::store($results);

        return $results;
    }

    public static function APIMode()
    {
        $varDir = pm_Context::getVarDir();
        $configFile = $varDir.'basekit.ini';
        $defaultConfigs = parse_ini_file($configFile);

        if ($defaultConfigs['manual_configuration'] === "0") {
            return 'auto';
        }

        return 'manual';
    }

    private static function fakeExtBaseKitKABody()
    {
        $expectedValues = [
            'key-body' => json_encode([
                'apiUrl' => "https://rest.bk-partnersus.com",
                'brandRef' => 47,
                'resellerRef' => null,
                'consumerKey' => "test",
                'consumerSecret' => "DrlnqdYYQsS3JUBDuEjUBBdmFIvbEJo0u5HXeVCl22jTRY4pr5",
                'accessToken' => "Q9CEov9Ghd7bbuHx3jFBj7VaCTvflRqXi1qZo8Xglj8V50wLPP",
                'accessSecret' => "60HHeA1MPFcz8TlwG2qJ2hHBgljeOvoX9g3fblpAl2k3iIArEo",
                'environmentIpAddress' => "50.18.217.93",
                'publishedSitesDomain' => "bk-partnersus.com"
            ])
        ];

        return $expectedValues;
    }

    public static function getPleskVersion()
    {
        $request = <<< EOT
            <server>
                <get>
                    <stat/>
                </get>
            </server>
EOT;
        $response = pm_ApiRpc::getService()->call($request);

        if (isset($response->server->get->result->status) && $response->server->get->result->status == 'ok') {
            $stat = $response->server->get->result->stat->version;

            return $stat->plesk_version->__toString();
        }

        return '12.5';
    }

    public static function isPlesk12()
    {
        $version = self::getPleskVersion();
        return version_compare($version, '12.5', '>=') && version_compare($version, '17.0', '<');
    }

    public static function isPlesk17()
    {
        return version_compare(self::getPleskVersion(), '17.0', '>=');
    }

    public static function plansChangedToNone($oldConfigs, $newConfigs)
    {
        $plans = array();
        foreach ($newConfigs as $newConfigName => $newConfigValue) {
            if (strpos($newConfigName, "config_") !== false && strpos($newConfigName, "_plan") !== false && ($newConfigValue == null || $newConfigValue == "")) {

                if (array_key_exists($newConfigName, $oldConfigs) && $oldConfigs[$newConfigName] != "") {
                    $plans[] = str_replace("_plan", "", str_replace("config_", "", $newConfigName));
                }
            }
        }
        return $plans;
    }
}