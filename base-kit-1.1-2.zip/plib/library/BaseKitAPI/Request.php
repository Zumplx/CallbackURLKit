<?php

use BaseKit\Api\Client;

/**
 * Description of MHTAPI
 *
 * @author Michal Czech <michael@modulesgarden.com>
 */
abstract class Modules_BaseKit_BaseKitAPI_Request
{
    /**
     *
     * @var Main\models\service\server
     */
    private $_server;
    private $_client;
    public $_oauth = false;

    /**
     * Setup Server
     * 
     * @param Main\models\service\server $server
     */
    function __construct($server)
    {
        $this->_server = $server;
        
        try {
            if ($this->_oauth) {
                $this->_client = \BaseKit\Api\Client::factory(
                        array(
                            'base_url' => $server->baseUrl,
                            'consumer_key' => $server->consumerKey,
                            'consumer_secret' => $server->consumerSecret,
                            'token' => $server->token,
                            'token_secret' => $server->tokenSecret,
                        )
                );
            } else {
                $this->_client = \BaseKit\Api\BasicClient::factory(
                        array(
                            'base_url' => $server->baseUrl,
                            'basicAuthUsername' => $server->baseUsername,
                            'basicAuthPassword' => $server->basePassword,
                        )
                );
            }
        } catch (\Exception $ex) {
            $this->_client = null;
        }
    }

    /**
     * Send Request To BaseKit API
     * 
     * @param string $method
     * @param array $params
     * @param array $content
     * @return array
     * @throws Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI
     */
    protected function _request($method, array $params = array(), array $content = array(), $apiAction, $pleskSub = array())
    {
        $buildUrl = '';
        foreach ($params as $key => $value) {
            if (is_string($key)) {
                $buildUrl .= '/'.$key.'/'.$value;
            } else {
                $buildUrl .= '/'.$value;
            }
        }
        $buildUrl = str_replace("//", "/", $buildUrl);
        $url = $this->_server->baseUrl.$buildUrl;

        $body = $method === 'GET' ? null : json_encode($content);

        $headers = array('Content-type' => 'application/json');

        $debugContent['request'] = array(
            'url' => $url,
            'method' => $method,
            'headers' => $headers,
            'body' => $body
        );

        try {
            $request = $this->_client->createRequest($method, $url, $headers, $body);
            
            if($this->_oauth == false){
                $request->setAuth($this->_server->baseUsername,$this->_server->basePassword );
            }

            $response = $request->send();

            $debugContent['response'] = array(
                'isSuccessful' => $response->isSuccessful(),
                'isInformational' => $response->isInformational(),
                'isClientError' => $response->isClientError(),
                'isServerError' => $response->isServerError(),
                'headers' => array(
                    'cacheControl' => $response->getCacheControl(),
                    'ContentType' => $response->getContentType(),
                    'ContentLength' => $response->getContentLength(),
                    'ContentEncoding' => $response->getContentEncoding(),
                    'ContentMd5' => $response->getContentMd5(),
                    'Etag' => $response->getEtag(),
                ),
                'body' => $response->getBody(true)
            );

            $responseJson = $response->getBody(true);
            $responseStatus = $response->getStatusCode();
            $parsedData = @json_decode($responseJson, true);
        } catch (\Exception $ex) {
            $parsedData = array();
            $debugContent['response'] = array(
                'body' => $ex->getMessage() //pm_Locale::lmsg('connection_error')
            );

            if (
                method_exists($ex, 'getResponse') && method_exists($ex->getResponse(), 'getBody') && $responseJson = $ex->getResponse()->getBody(true)
            ) {
                $parsedData = @json_decode($responseJson, true);
                $debugContent['response'] = array(
                    'body' => $responseJson
                );
            }

            if (isset($parsedData['message']) && $parsedData['message']) {
                $errList = array();
                if (isset($parsedData['errors'])) {
                    if (is_array($parsedData['errors'])) {
                        foreach ($parsedData['errors'] as $sub) {
                            if (is_array($sub)) {
                                foreach ($sub as $subb) {
                                    $errList[] = $subb;
                                }
                            }
                        }
                    }
                }

                $message = $parsedData['message'];

                if ($errList) {
                    $message .= ': '.implode(', ', $errList);
                }
                throw new Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI($apiAction, $message, $parsedData['code'], $debugContent, $pleskSub);
            }



            throw new Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI($apiAction, $ex->getMessage(), $ex->getCode(), $debugContent, $pleskSub);
        }


        if (!(
            ($responseStatus == 200 && in_array($method, array('GET', 'PUT', 'POST'))) || ($responseStatus == 201 && in_array($method, array('POST'))) || ($responseStatus == 204 && in_array($method,
                array('DELETE')))
            )) {
            if ($parsedData['message']) {
                $errList = array();
                if (is_array($parsedData['errors'])) {
                    foreach ($parsedData['errors'] as $sub) {
                        if (is_array($sub)) {
                            foreach ($sub as $subb) {
                                $errList[] = $subb;
                            }
                        }
                    }
                }

                $message = $parsedData['message'];

                if ($errList) {
                    $message .= ': '.implode(', ', $errList);
                }
                throw new Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI($apiAction, $message, $parsedData['code'], $debugContent, $pleskSub);
            } else {
                throw new Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI($apiAction, 'Error Code', $responseStatus, $debugContent, $pleskSub);
            }
        }

        if (isset($parsedData['error'])) {
            throw new Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI($apiAction, $parsedData['error']['message'], $parsedData['error']['code'], $debugContent, $pleskSub);
        }

        Modules_BaseKit_Model_APILogs::store($apiAction, md5(microtime()), "", $debugContent, 'Success', $pleskSub);

        $debugData['response'] = $parsedData;
        return $parsedData;
    }
}