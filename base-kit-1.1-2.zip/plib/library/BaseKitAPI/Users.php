<?php
class Modules_BaseKit_BaseKitAPI_Users extends Modules_BaseKit_BaseKitAPI_Request
{

    /**
     * Get Users List
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @return array
     */
    function lists($limit = 20, $ofset = 0, $pleskSub = array())
    {
        $data = $this->_request('GET', array('users?limit='.$limit.'&offset='.$ofset), array(), 'Users: Get Users', $pleskSub);
        return $data['accountHolders'];
    }

    /**
     * Create User
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $brandRef
     * @param string $firstName
     * @param string $lastName
     * @param string $username
     * @param string $password
     * @param string $email
     * @param string $languageCode
     * @return array
     */
    function create($brandRef, $firstName, $lastName, $username, $password, $email, $languageCode, $resellerRef = null, $pleskSub = array())
    {
        $requestArray = array(
            'firstName' => $firstName
            , 'lastName' => $lastName
            , 'username' => $username
            , 'password' => $password
            , 'email' => $email
            , 'brandRef' => $brandRef
            , 'languageCode' => $languageCode
        );
        if (!empty($resellerRef)) {
            $requestArray['resellerRef'] = $resellerRef;
        }
        $result = $this->_request('POST', array('users'), $requestArray, 'Users: Create User', $pleskSub);

        return $result['accountHolder'];
    }

    function edit($userRef, $firstName, $lastName, $username, $password, $email, $languageCode, $pleskSub = array())
    {
        $requestArray = array(
            'firstName' => $firstName
            , 'lastName' => $lastName
            , 'username' => $username
            , 'password' => $password
            , 'email' => $email
            , 'languageCode' => $languageCode
        );

        $result = $this->_request('PUT', array('users', $userRef), $requestArray, 'Users: Edit User', $pleskSub);

        return $result['accountHolder'];
    }

    /**
     * Get User
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $userRef
     * @return array
     */
    function get($userRef, $pleskSub = array())
    {
        $result = $this->_request('GET', array('users' => $userRef), array(), 'Get User', $pleskSub);

        $result['accountHolder']['subscriptionPackageRef'] = $this->getPlanId($result['accountHolder']['subscriptionPackageRef'], $result['accountHolder']['ref']);
        return $result['accountHolder'];
    }

    /**
     * Remove User
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $userRef
     */
    function remove($userRef, $pleskSub = array())
    {
        $this->_request('DELETE', array('users' => $userRef), array(), 'Users: Delete User', $pleskSub);
    }

    /**
     * Add Package To User
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $userRef
     * @param int $packageRef
     */
    function addPackage($userRef, $packageRef, $billingFrequency = null, $pleskSub = array())
    {

        $data = array(
            'packageRef' => $packageRef
        );

        if ($billingFrequency !== null) {
            $data['billingFrequency'] = $billingFrequency;
        }

        $response = $this->_request("POST", array('users' => $userRef, 'account-packages'), $data, 'Users: Add User Package', $pleskSub);

        return $response;
    }

    /**
     * Get User Packages
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $userRef
     * @return array
     */
    function getPackages($userRef, $pleskSub = array())
    {
        $data = $this->_request("GET", array('users' => $userRef, 'account-packages'), array(), 'Users: Get User\'s Package', $pleskSub);

        return $data['accountPackages'];
    }

    /**
     * Generate Auto Login Hash
     * 
     * @param int $userRef
     * @return string
     */
    function autoLoginHash($userRef, $pleskSub = array())
    {
        $result = $this->_request('POST', array('users' => $userRef, 'auto-login'), array(), 'Users: Create auto-login hash', $pleskSub);

        return $result['hash'];
    }

    private function getPlanId($planId, $ref, $pleskSub = array())
    {
        $plans = Modules_BaseKit_Model_ServicePlan::getAvailablePlans();
        if (isset($plans[$planId])) {
            return $planId;
        } else {
            $db = new Modules_BaseKit_BaseKit_Database();
            $query = $db->prepare("SELECT plan FROM BaseKit_Customer_Data WHERE baseKitRef=?");
            $query->execute(array($ref));
            $plan = $query->fetch(PDO::FETCH_OBJ)->plan;

            foreach ($plans as $id => $package) {
                if ($package == $plan) {
                    return $id;
                }
            }
            return Modules_BaseKit_Model_ServicePlan::getNameFromConfig($plan);
        }
    }
}