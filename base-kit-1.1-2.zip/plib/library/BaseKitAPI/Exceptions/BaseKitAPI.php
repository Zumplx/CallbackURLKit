<?php
/**
 * Base Kit API Exception
 *
 * @author Michal Czech <michael@modulesgarden.com>
 */
class Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI extends Modules_BaseKit_Exceptions_Base{
    private $debugData;
    
    /**
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param string $message
     * @param array $debugData
     */
    function __construct($apiAction, $message, $code,$debugData = array(), $pleskSub = array()) {
        parent::__construct($message, $code);
        $this->debugData = $debugData;

        $errorContent = array_merge($debugData, $this->getTrace());

        Modules_BaseKit_Model_APILogs::store($apiAction, $this->getToken(), $this->getMessage(), $errorContent, 'Fail', $pleskSub);
    }
}
