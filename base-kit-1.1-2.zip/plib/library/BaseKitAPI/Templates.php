<?php
class Modules_BaseKit_BaseKitAPI_Templates extends Modules_BaseKit_BaseKitAPI_Request
{

    /**
     * Get Site Templates
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @return array
     */
    function getTemplates($pleskSub = array())
    {
        $result = $this->_request('GET', array('v2' => 'templates'), array(), 'Get Tempaltes', $pleskSub);
        echo '<pre>';
        var_dump($result);
        echo '</pre>';
        die;
        return $result['templates'];
    }
}