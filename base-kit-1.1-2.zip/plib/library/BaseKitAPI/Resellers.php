<?php
/*
 *  * ******************************************************************
 * 
 *    CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *    AUTHOR                         ->        Dariusz Bijos <dariusz.bi@modulesgarden.com>
 *    CONTACT                        ->        contact@modulesgarden.com
 * 
 *   This software is furnished under a license and may be used and copied
 *   only  in  accordance  with  the  terms  of such  license and with the
 *   inclusion of the above copyright notice.  This software  or any other
 *   copies thereof may not be provided or otherwise made available to any
 *   other person.  No title to and  ownership of the  software is  hereby
 *   transferred.
 * 
 *  * ******************************************************************
 */
class Modules_BaseKit_BaseKitAPI_Resellers extends Modules_BaseKit_BaseKitAPI_Request
{

    public function getResellers($brandRef, $pleskSub = array())
    {
        $result = $this->_request('GET', array('brands' => (int)$brandRef, 'resellers'), array(), 'Resellers: Get Brand Resellers', $pleskSub);
        return $result;
    }
}