<?php
/**
 * Brand API
 *
 * @author Michal Czech <michael@modulesgarden.com>
 */
class Modules_BaseKit_BaseKitAPI_Brands extends Modules_BaseKit_BaseKitAPI_Request
{

    /**
     * Get Avaiable Langs for brand
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $brandRef
     * @return array
     */
    function getLangs($brandRef, $pleskSub = array())
    {
        $result = $this->_request('GET', array('brands' => (int) $brandRef, 'languages'), array(), 'Brands: Get Languages', $pleskSub);

        return $result['languages'];
    }

    function packages($brandRef, $pleskSub = array())
    {
        $result = $this->_request('GET', array('brands' => (int) $brandRef, 'packages'), array(), 'Brands: Get Packages', $pleskSub);

        return $result['packages'];
    }
}