<?php
class Modules_BaseKit_BaseKitAPI_Sites extends Modules_BaseKit_BaseKitAPI_Request
{

    /**
     * 
     * @param int $brandRef
     * @return array
     */
    function lists($brandRef, $addictionalParams = array(), $pleskSub = array())
    {

        $getString = "sites?brandRef=".$brandRef;

        if (!empty($addictionalParams)) {
            foreach ($addictionalParams as $key => $value) {
                $getString .= "&".$key."=".$value;
            }
        }

        return $this->_request('GET', array($getString), array(), 'Sites: Get Sites' ,$pleskSub);
    }

    /**
     * Create Site
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $brandRef
     * @param int $accountHolderRef
     * @param string $domain
     * @param int $templateRef
     * @param string $siteType
     * @param string $activationStatus
     * @return array
     */
    function create($brandRef, $accountHolderRef, $domain, $templateRef, $siteType = 'responsive', $activationStatus = 'inactive', $pleskSub = array())
    {
        $detailsArray = array(
            'brandRef' => $brandRef
            , 'accountHolderRef' => $accountHolderRef
            , 'domain' => $domain
            , 'siteType' => $siteType);
        if (!empty($templateRef)) {
            $detailsArray['templateRef'] = $templateRef;
        }
        $result = $this->_request('POST', array('sites'), $detailsArray, 'Sites: Create Site' ,$pleskSub);

        return $result['site'];
    }

    /**
     * Update Site 
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $siteRef
     * @param int $templateRef
     * @param string $activationStatus
     * @param string $primaryUrlRef
     * @param string $enabled
     * @return array
     */
    function update($siteRef, $templateRef = null, $activationStatus = null, $primaryUrlRef = null, $enabled = null, $pleskSub = array())
    {
        $data = array();

        if ($primaryUrlRef !== null) {
            $data['primaryUrlRef'] = $primaryUrlRef;
        }

        if ($enabled !== null) {
            $data['enabled'] = $enabled;
        }

        if ($templateRef !== null) {
            $data['templateRef'] = $templateRef;
        }

        if ($activationStatus !== null) {
            $data['activationStatus'] = $activationStatus;
        }

        $result = $this->_request('PUT', array('sites' => $siteRef), $data, 'Sites: Edit Site' ,$pleskSub);

        return $result['site'];
    }

    /**
     * Remove Site
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $siteRef
     */
    function remove($siteRef, $pleskSub = array())
    {
        $this->_request('DELETE', array('sites' => $siteRef), array(), 'Sites: Delete Site' ,$pleskSub);
    }

    /**
     * Get Site
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $siteRef
     * @return array
     */
    function get($siteRef, $pleskSub = array())
    {
        $data = $this->_request('GET', array('sites' => $siteRef), array(), 'Sites: Get Site' ,$pleskSub);
        return $data['site'];
    }

    /**
     * Map Domain
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $siteRef
     * @param string $domain
     */
    function mapDomain($siteRef, $domain, $pleskSub = array())
    {
        $data = $this->_request("POST", array('sites' => $siteRef, 'domains'), array('domain' => $domain), 'Sites: Map Domain' ,$pleskSub);

        return $data['domainToSiteMap'];
    }

    /**
     * UnMap Domain
     * 
     * @author Michal Czech <michael@modulesgarden.com>
     * @param int $siteRef
     * @param int $domainRef
     */
    function unMapDomain($siteRef, $domainRef, $pleskSub = array())
    {
        $this->_request("DELETE", array('sites' => $siteRef, 'domains' => $domainRef), array(), 'Sites: Unmap Domain' ,$pleskSub);
    }
}