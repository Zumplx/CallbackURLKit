<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

/**
 * IndexController Moduel Admin Area Controller
 * @version 1.0.0
 * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
 */
class IndexController extends pm_Controller_Action
{

    /**
     * init
     * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
     * @since 1.0.0
     * This method is executed always while IndexController is used (Moduel Admin Area)
     */
    public function init()
    {
        parent::init();
        $session = new \pm_Session;

        if (!defined('DS')) {
            define('DS', DIRECTORY_SEPARATOR);
        }

        if ($session->getClient()->isReseller()) {
            header('location: /');
            die();
        }

        if ($session->getClient()->isClient()) {
            $this->_redirect('client');
        }

        $this->view->pageTitle = pm_Locale::lmsg('module_name');
        $this->view->tabs = array(
            array(
                'title' => pm_Locale::lmsg('tab_config'),
                'action' => 'index',
            ),
            array(
                'title' => pm_Locale::lmsg('tab_logs'),
                'action' => 'apilogs',
            )
        );
    }

    /**
     * Default Index Action - Configuration
     * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
     * @since 1.0.0
     * return View
     */
    public function indexAction()
    {
        $this->view->pageTitle = pm_Locale::lmsg('module_name');
        $r = new ReflectionMethod('pm_Locale', 'lmsg');
        $params = $r->getParameters();
        $customerModel = new Modules_BaseKit_Model_Customers();
        if (Modules_BaseKit_PleskService::APIMode() === "auto") {
            $formParts[] = 'api_configuration';
            $config = Modules_BaseKit_PleskService::getKAApiDetails();
            //Error - KA license not installed
            if ($config['keybodyempty']) {
                $this->view->errorMessage = pm_Locale::lmsg('addon_additional_license_key_missing').' <a href="'.$this->_getBuyUrl().'" target="_blank">'.$this->_getBuyUrl().'<a/>';
                return;
            }
            //Error - Missing some parameters in KA license
            if (!empty($config['missing_params'])) {
                $this->view->missing_params = $config['missing_params'];
            }
        }

        $form = Modules_BaseKit_Form_Configuration::get($config);
        $configuration = Modules_BaseKit_BaseKit_Config::getInstance();
        $populateData = empty($configuration::get()) ? array() : $configuration::get();

        $form->populate($populateData);
        $this->view->form = $form;
    }

    /**
     * Save Config Action - Configuration Save 
     * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
     * @since 1.0.0
     * redirect or return form View
     */
    public function configsaveAction()
    {
        if ($this->_request->isPost()) {
            $configuration = Modules_BaseKit_BaseKit_Config::getInstance();
            $config = null;
            if (Modules_BaseKit_PleskService::APIMode() === "auto") {
                $config = Modules_BaseKit_PleskService::getKAApiDetails();
            }
            $form = Modules_BaseKit_Form_Configuration::get($config);

            $postConfigData = $this->_request->getPost();
            if ($form->isValidPartial($this->getRequest()->getPost())) {
                $configData = $form->getValues();

                $domainModel = new Modules_BaseKit_Model_Domains();
                if ((int) $configData['config_auto_set_dns'] == 1) {
                    $plansChangedToNone = Modules_BaseKit_PleskService::plansChangedToNone($configuration::get(), $configData);
                    if (!empty($plansChangedToNone)) {
                        $domainsToRemoveDNS = $domainModel->domainsToRemoveDNS($plansChangedToNone);
                        foreach ($domainsToRemoveDNS as $subKey => $subDomainsToRemoveDNS) {
                            foreach($subDomainsToRemoveDNS as $subDomainToRemoveDNS){
                            $domainModel->removeARecordForDomain($subDomainToRemoveDNS['id']);
                            $domainModel->restoreAssignedIPAAdress($subDomainToRemoveDNS['id']);
                            }
                        }
                    }
                } else {
                    $clientModel = new Modules_BaseKit_Model_Customers();
                    $mappedDomains = $clientModel->getBaseKitSubscriptionUsers();
                    foreach ($mappedDomains as $domainToRemoveDNS) {
                        $subDomainsToRemoveDNS = $domainModel->getSubscriptionDomains($domainToRemoveDNS['plesk_domainsubid']);
                        foreach($subDomainsToRemoveDNS as $subDomainToRemoveDNS){
                            if(isset($subDomainToRemoveDNS['id']) && $subDomainToRemoveDNS['id'] != ""){
                            $domainModel->removeARecordForDomain($subDomainToRemoveDNS['id']);
                            $domainModel->restoreAssignedIPAAdress($subDomainToRemoveDNS['id']);
                            }
                        }
                    }
                }

                $configuration = Modules_BaseKit_BaseKit_Config::getInstance();
                $status = ($configuration::store($configData)) ? 1 : 0;

                //pm_Settings::set('BaseKit_Config', serialize($configData));

                $message = $status ? pm_Locale::lmsg('config_save_successful') : pm_Locale::lmsg('config_save_failed');
                $this->_status->addMessage('info', $message);
                $this->_helper->json(array('status' => $status, 'redirect' => '/modules/base-kit/index.php/index/'));
            }
            $this->view->form = $form;
            $this->render('index');
        }
    }

    /**
     * Test Connection Action - test Connection
     * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
     * @since 1.0.0
     * redirect or return form View
     */
    public function testconnectionAction()
    {
        try {
            $config = $this->getRequest()->getPost();
            $api = new Modules_BaseKit_BaseKit_API($config);
            $data = $api->users()->lists(1);
        } catch (Modules_BaseKit_BaseKitAPI_Exceptions_BaseKitAPI $e) {
            $this->_helper->json(array('status' => 'error', 'msg' => sprintf(pm_Locale::lmsg('test_connection_failed'), '/modules/base-kit/index.php/index/showtoken/token/'.$e->getToken(),
                    $e->getToken()),
                'details' => $e->getMessage()));
        }
        $this->_helper->json(array('status' => 'info', 'msg' => pm_Locale::lmsg('test_connection_success')));
    }

    /**
     * Logs Tab
     * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
     * @since 1.0.0
     * Display Logs
     */
    public function apilogsAction()
    {
        $this->view->tabPageTitle = pm_Locale::lmsg('tab_logs');
        $this->view->list = $this->getApiLogsList();
        $this->view->form = Modules_BaseKit_Form_APILogsClear::get();
    }

    public function requestsapilogsAction()
    {
        $this->view->tabPageTitle = pm_Locale::lmsg('tab_logs');
        $this->view->list = $this->getApiLogsList();
        $this->view->form = Modules_BaseKit_Form_APILogsClear::get();
    }

    /**
     * Logs List Table
     * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
     * @since 1.0.0
     * Create Logs Table
     */
    public function getApiLogsList()
    {
        $options = [
            'defaultSortField' => 'column-4',
            'defaultSortDirection' => pm_View_List_Simple::SORT_DIR_DOWN,
        ];

        $_SESSION["panel"]["pm_View_List_Simple"]["sort-field"] = "column-5";
        $_SESSION["panel"]["pm_View_List_Simple"]["sort-dir"] = 'down';

        $list = new pm_View_List_Simple($this->view, $this->_request, $options);
        $list->setColumns(array(
            'column-1' => array(
                'title' => pm_Locale::lmsg('apilogs_token'),
                'noEscape' => true,
                'sortable' => true,
                'searchable' => true,
            ),
            'column-2' => array(
                'title' => pm_Locale::lmsg('apilogs_actions'),
                'noEscape' => true,
                'sortable' => true,
                'searchable' => false,
            ),
            'column-3' => array(
                'title' => pm_Locale::lmsg('apilogs_subscriptions'),
                'noEscape' => true,
                'sortable' => true,
                'searchable' => false,
            ),
            'column-4' => array(
                'title' => pm_Locale::lmsg('apilogs_status'),
                'noEscape' => true,
                'sortable' => true,
                'searchable' => false,
            ),
            'column-5' => array(
                'title' => pm_Locale::lmsg('apilogs_datetime'),
                'noEscape' => true,
                'searchable' => true,
                'sortable' => true,
            ),
        ));

        $data = array();
        $apiLogs = Modules_BaseKit_Model_APILogs::getAll();

        if (!empty($apiLogs)) {
            foreach ($apiLogs as $row) {


                if ($row['subscription'] != null && $row['subscription'] != "") {
                    $domainModel = new Modules_BaseKit_Model_Domains();
                    $domainData = $domainModel->pleskDomain($row['subscription']);
                    $subId = $domainModel->pleskDomainSubscriptionId($row['subscription']);
                    $planId = $domainModel->pleskDomainPlanSubscription($subId);
                    $plan = $domainModel->pleskDomainPlan($planId['plan_id']);
                    if ($row['subscription'] && $domainData['name'] && $plan['name']) {
                        $subscription = '<a href=/admin/subscription/overview/id/'.$this->view->escape($row['subscription']).'>'.$this->view->escape($domainData['name']).' ('.$this->view->escape($plan['name']).')</a>';
                    } elseif (!is_numeric($row['subscription'])) {
                        $subscription = $row['subscription'];
                    } else {
                        $subscription = pm_Locale::lmsg('none');
                    }
                } else {
                    $subscription = pm_Locale::lmsg('none');
                }

                if ($row['status'] == 'Success') {
                    $status = '<strong class="success">'.$this->view->escape($row['status']).'</strong>';
                } else {
                    $status = '<strong class="fail">'.$this->view->escape($row['status']).'</strong>';
                }

                $data[] = array(
                    'column-1' => '<a href=/modules/base-kit/index.php/index/showtoken/token/'.$this->view->escape($row['token']).'>'.$this->view->escape($row['token']).'</a>',
                    'column-2' => $this->view->escape($row['apiaction']),
                    'column-3' => $subscription,
                    'column-4' => $status,
                    'column-5' => $this->view->escape($row['created_at']),
                );
            }

            $list->setData($data);
            $list->setDataUrl(array('action' => 'apilogsjson'));
        }
        return $list;
    }

    /**
     * Api Logs Sorting
     * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
     * @since 1.0.0
     * return Json
     */
    public function apilogsjsonAction()
    {
        $this->_helper->json($this->getApiLogsList()->fetchData());
    }

    /**
     * Token Description
     * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
     * @since 1.0.0
     * Display Error Token Details
     */
    public function showtokenAction()
    {
        $request = $this->_request->getParams();
        $token = $request['token'];
        $data = Modules_BaseKit_Model_APILogs::getLog($token);

        $this->view->goBack = pm_Locale::lmsg('apilogs_goback');
        $this->view->token = $data['token'];
        $this->view->errorMessage = $data['error_message'];
        $this->view->debugData = unserialize($data['debug_data']);
    }

    /**
     * Clear Api Logs
     * @author Dariusz Bijos <dariusz.bi@modulesgarden.com>
     * @since 1.0.0
     * Delete Logs
     */
    public function apilogsclearAction()
    {
        if ($this->_request->isPost()) {
            Modules_BaseKit_Model_APILogs::clear();
            $this->_status->addMessage('info', pm_Locale::lmsg('apilogs_clear_success'));
            $this->_helper->json(array('status' => 1, 'redirect' => '/modules/base-kit/index.php/index/apilogs'));
        }
    }

    private function _getBuyUrl()
    {

        if (method_exists('pm_Context', 'getBuyUrl')) {

            return pm_Context::getBuyUrl();
        }

        return (new SimpleXMLElement(file_get_contents(pm_Context::getPlibDir().'/meta.xml')))->buy_url;
    }
}