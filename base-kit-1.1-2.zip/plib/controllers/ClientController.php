<?php
/*
 * * ******************************************************************
 *
 *   CREATED BY MODULESGARDEN       ->        http://modulesgarden.com
 *   AUTHOR                         ->     dariusz.bi@modulesgarden.com
 *   CONTACT                        ->       contact@modulesgarden.com
 *
 *  This software is furnished under a license and may be used and copied
 *  only  in  accordance  with  the  terms  of such  license and with the
 *  inclusion of the above copyright notice.  This software  or any other
 *  copies thereof may not be provided or otherwise made available to any
 *  other person.  No title to and  ownership of the  software is  hereby
 *  transferred.
 *
 * * ******************************************************************
 */

class ClientController extends pm_Controller_Action
{
    private $clientid;

    public function init()
    {
        parent::init();
        $session = new \pm_Session;
        if (!defined('DS')) {
            define('DS', DIRECTORY_SEPARATOR);
        }


        if (isset($_SESSION['auth']['sessionClientId'])) {
            $this->clientid = $_SESSION['auth']['sessionClientId'];
        } elseif (isset($_SESSION['auth']["clientId"])) {
            $this->clientid = $_SESSION['auth']["clientId"];
        } else {
            $this->clientid = null;
        }

        //$this->clientid = isset($_SESSION['auth']['sessionClientId']) ? $_SESSION['auth']['sessionClientId'] : isset($_SESSION['auth']["clientId"]) ? $_SESSION['auth']["clientId"] : null;
    }

    public function indexAction()
    {
        if ($_SESSION["subscription"]["showAll"] === true) {
            header('location: /smb/account/switch/all/false/id/'.$_SESSION["subscription"]["currentId"].'?hideNotice=1&returnUrl=%2Fsmb%2Fredirect%2Fpleskin%3Fdst%3D%252Fmodules%252Fbase-kit%252Findex.php%252Fclient%252Findex%252Findex%253F&changeId=1&activeModule=');
            die;
        }

        $clientModel = new Modules_BaseKit_Model_Customers();
        $domainModel = new Modules_BaseKit_Model_Domains();

        //Create Subscription for unsubscribed domains
        $clientDomainsWithoutSub = $clientModel->getClientDomainsWithoutSub($this->clientid);
        $Modules_BaseKit_BKService = new Modules_BaseKit_BKService();
        
        if (!empty($clientDomainsWithoutSub)) {
            $clientDetails = $clientModel->getClientDataById($this->clientid);
            foreach ($clientDomainsWithoutSub as $clientDomainWithoutSub) {
                $Modules_BaseKit_BKService->addBaseKitUserPackage($clientDomainWithoutSub['id']);
            }
        }
        //End Create Subscriptions
        if (!$clientModel->getBaseKitSubscriptionUserByPleskDomainId($_SESSION["subscription"]["currentId"])) {
            $this->view->error = pm_Locale::lmsg('subscription_error');
            return;
        }


        $this->view->loginsLinks = null;

        if ($this->_request->isPost()) {
            $action = $this->_getParam('module_action');
            switch ($action) {
                case 'map_domain':
                    $mappedDomainId = $this->_getParam('mapping_domain');
                    $mapDomain = $Modules_BaseKit_BKService->mapDomain($this->clientid, $mappedDomainId);

                    if ($mapDomain !== true) {
                        $this->view->error = $mapDomain;
                    } else {
                        $this->view->message = pm_Locale::lmsg('mapped_success');
                    }
                    break;
                case 'unmap_domain':
                    $unmappedDomainId = $this->_getParam('unmapping_domain');
                    $domainid = $this->_getParam('domainid');
                    $unmapDomain = $Modules_BaseKit_BKService->unmapDomain($this->clientid, $unmappedDomainId, $this->_getParam('siteRef'), $domainid);
                    if ($unmapDomain !== true) {
                        $this->view->error = $unmapDomain;
                    } else {
                        $this->view->message = pm_Locale::lmsg('unmapped_success');
                    }
                    break;
                case 'makeprimary_domain':
                    $newPrimaryDomainId = $this->_getParam('makeprimary_domain');
                    $makePrimary = $Modules_BaseKit_BKService->makePrimaryDomain($this->clientid, $newPrimaryDomainId, $this->_getParam('siteRef'));
                    if ($makePrimary !== true) {
                        $this->view->error = $makePrimary;
                    } else {
                        $this->view->message = pm_Locale::lmsg('makeprimary_success');
                    }
                    break;
            }
        }

        $clientDomains = $clientModel->getDomains($this->clientid);

        $session = new \pm_Session();

        if ($session->getClient()->isAdmin() || $session->getClient()->isReseller()) {
            $clientDomains = $clientModel->getSubscriptiondomains($_SESSION["subscription"]["currentId"]);
            $mappedDomains = $Modules_BaseKit_BKService->getClientSubscriptionMappedDomains($this->clientid, $_SESSION["subscription"]["currentId"]);
            $domainSubId = $domainModel->pleskDomainSubscriptionId($_SESSION["subscription"]["currentId"]);
            $form = Modules_BaseKit_Form_Mapping::get(array('clientDomains' => $clientDomains, 'mappedDomains' => $mappedDomains));
        } else {
            $mappedDomains = $Modules_BaseKit_BKService->getClientSubscriptionMappedDomains($this->clientid, $_SESSION["subscription"]["currentId"]);
            $domainSubId = $domainModel->pleskDomainSubscriptionId($_SESSION["subscription"]["currentId"]);
            $clientDomains = $clientModel->getClientSubscriptionDomains($this->clientid, $domainSubId);
            $form = Modules_BaseKit_Form_Mapping::get(array('clientDomains' => $clientDomains, 'mappedDomains' => $mappedDomains));
        }

        $this->view->form = $form;
        $this->view->mappedDomains = $mappedDomains;
        if (is_string($this->getMappedDomainList())) {
            $this->view->error = pm_Locale::lmsg('general_error');
            return;
        }


        $this->view->list = $this->getMappedDomainList();
    }

    public function getMappedDomainList()
    {
        $data = array();
        $Modules_BaseKit_BKService = new Modules_BaseKit_BKService();
        $customerModel = new Modules_BaseKit_Model_Customers();
        $clientdata = $customerModel->getClientDataById($this->clientid);
        $config = Modules_BaseKit_BaseKit_Config::get();
        $mappedDomains = $Modules_BaseKit_BKService->getClientSubscriptionMappedDomains($this->clientid, $_SESSION["subscription"]["currentId"]);

        if (is_string($mappedDomains)) {
            return $mappedDomains;
        }
        if (is_array($mappedDomains)) {
            foreach ($mappedDomains as $mappedDomain) {
                $actionButtons = "";
                if ((int) $mappedDomain['primary'] == 0) {
                    $actionButtons .= '<button type="button" id="makeprimary_'.$this->view->escape($mappedDomain['domainref']).'" data-domainid="'.$this->view->escape($mappedDomain['pleskdomainid']).'" data-siteref="'.$this->view->escape($mappedDomain['siteref']).'" class="btn btn-info btn-xs">'.$this->view->escape(pm_Locale::lmsg('make_as_primary')).'</button>';
                    if (strpos($mappedDomain['name'], $config['config_partner_domain']) === false) {
                        $actionButtons .= '<button type="button" id="unmap_'.$this->view->escape($mappedDomain['domainref']).'" data-domainid="'.$this->view->escape($mappedDomain['pleskdomainid']).'" data-siteref="'.$this->view->escape($mappedDomain['siteref']).'" class="btn btn-info btn-xs">'.$this->view->escape(pm_Locale::lmsg('unmap')).'</button>';
                    }
                } else {
                    $loginLinks = $customerModel->getLoginsLinks($this->clientid, $_SESSION["subscription"]["currentId"]);
                    $actionButtons .= '<button type="button" class="btn btn-info btn-xs" disabled>Primary Domain</button><a href="'.$this->view->escape($loginLinks[$_SESSION["subscription"]["currentId"]]).'" id="mapping_login" class="btn" target="_blank">'.$this->view->escape(pm_Locale::lmsg('login')).'</a>';
                }


                $data[] = array(
                    'column-1' => $this->view->escape($mappedDomain['name']),
                    'column-2' => $actionButtons
                );
            }
        }

        $options = [
            'defaultSortField' => 'column-1',
            'defaultSortDirection' => pm_View_List_Simple::SORT_DIR_DOWN,
        ];

        $_SESSION["panel"]["pm_View_List_Simple"]["sort-field"] = "column-1";
        $_SESSION["panel"]["pm_View_List_Simple"]["sort-dir"] = 'down';

        $list = new pm_View_List_Simple($this->view, $this->_request, $options);

        $list->setData($data);
        $list->setColumns(array(
            'column-1' => array(
                'title' => pm_Locale::lmsg('mapping_domain_name'),
                'noEscape' => true,
                'sortable' => true,
            ),
            'column-2' => array(
                'title' => pm_Locale::lmsg('mapping_actions'),
                'noEscape' => true,
                'sortable' => false,
            )
        ));

        // Take into account listDataAction corresponds to the URL /list-data/
        $list->setDataUrl(array('action' => 'list-data'));

        return $list;
    }

    public function listDataAction()
    {
        $list = $this->getMappedDomainList();
        $this->_helper->json($list->fetchData());
    }
}