<?php
$messages = array(
    //************************** IndexController Module Admin Area **************************//
    'module_name' => "BaseKit Sitebuilder",
    'module_desc' => "If you're looking to build a professional website that's fully customisable and easy to manage, then BaseKit is answer.",
    'clientarea_module_desc' => "Click here to create a website, blog or online store with BaseKit.",
    'tab_config' => 'Configuration',
    'tab_logs' => 'Logs',
    //IndexController Module Admin Area Form
    'configuration_head' => 'Configuration',
    'config_base_url' => 'API URL',
    'config_base_username' => 'Base Auth Username',
    'config_base_password' => 'Base Auth Password',
    'config_brand_ref' => 'Brand Ref',
    'config_reseller_ref' => 'Reseller Ref',
    'config_consumer_key' => 'Consumer Key',
    'config_consumer_secret' => 'Consumer Secret',
    'config_access_token' => 'Access Token',
    'config_access_secret' => 'Access Secret',
    'config_server_ip' => 'BaseKit Server IP Address',
    'config_partner_domain' => 'BaseKit Partner Domain',
    'config_auto_set_dns' => 'Set A Record In Domain DNS Zone',
    'configuration_plans_head' => 'Plans Mapping',
    'configuration_plans_description' => 'Click below to associate your existing Plesk plan with BaseKit package',
    //Buttons
    'config_test_connection' => "Test Connection",
    'config_save' => "Save",
    //Messages
    'addon_additional_license_key_params_error' => 'Additional license key for your addon doesn\'t have required params.',
    'addon_additional_license_key_missing_params' => 'Missing Params:',
    'addon_additional_license_key_missing' => 'Addon additional license key is not installed. You can buy it under:',
    'config_save_successful' => 'Configuration Saved Successfully!',
    'config_save_failed' => 'Configuration Save Failed!',
    'test_connection_failed' => 'Cannot connect to the API. Please check entered details and try again. Error Token: <a href="%s" target="_blank">%s</a>',
    'test_connection_success' => 'You have supplied valid credentials. Please, remember to save your changes',
    'api_no_details' => 'Cannot create connection to API. Server connection details are empty!',
    'connection_error' => 'It is not possible to fetch Basekit Plans from the API (not authorized). Please contact support.',
    //Logs Tab
    'tab_logs' => 'Logs',
    //Logs Table List
    'apilogs_token' => 'Token',
    'apilogs_actions' => 'API Action',
    'apilogs_subscriptions' => 'Subscription',
    'apilogs_status' => 'Status',
    'apilogs_apimessage' => 'Error Message',
    'apilogs_loggedby' => 'User (id)',
    'apilogs_datetime' => 'Date/Time',
    'apilogs_clear' => 'Clear Logs',
    'apilogs_goback' => 'Go Back',
    //Api logs messages
    'apilogs_clear_success' => 'Logs removed successfully!',
    //Requests Logs tab
    'requests_tab_logs' => 'API requests Logs',
    //************************** ClientController Module Client Area **************************//
    'module_website_name' => "BaseKit",
    'module_website_ext_name' => "Extensions Catalog",
    'module_website_version' => "Version 1.2-1",
    'module_website_description' => "Launch a beautiful website, blog or online store with BaseKit. Start with a professionally designed template and create something truly unique with our fully stocked drag and drop content library. Our sitebuilder works on mobile phones, tablets and desktop computers so you can run your website, and your business on-the-go.",
    'module_website_instructions_head' => 'Instructions',
    'module_website_instructions' => "Edit and publish your website instantly with your unique sub-domain above. If you would like to use an existing domain, please select it from the drop-down list and click ‘Map’. If you don’t have a custom domain but would like to use one, please purchase it from your domain provider first. It will then be available to associate with your BaseKit website. Click ‘Log In’ to get started.",
    'module_website_note' => "*Please note that BaseKit sites are hosted on the BaseKit Cloud, not the infrastructure of your hosting provider.",
    'mapping_login_label' => "logIn",
    'mapping_map' => "Map",
    'mapping_cancel' => "Cancel",
    'mapping_domain_name' => "Domain",
    'mapping_actions' => "Actions",
    'mapped_success' => "Domain has been mapped successfully",
    'unmapped_success' => "Domain has been unmapped successfully",
    'makeprimary_success' => "Domain has been set as primary successfully",
    //Messages
    'subscription_error' => 'Website Builder is not available for this subscription',
    'unmap_user_error' => 'You trying unmap domain that not belong to you.',
    'makeprimary_user_error' => 'You trying make primary domain that not belong to you.',
    'map_user_error' => 'You trying map domain that not belong to you.',
    //Buttons
    'make_as_primary' => "Mark as primary",
    'unmap' => "Unmap",
    'login' => "Log In",
    //************************** Global Vars **************************//
    'none' => 'None',
    //************************** Global Messages **************************//
    'glob_info_title' => 'Information',
    'general_error' => 'Something has gone wrong. Please contact with admin.'
);
