# 1.0

* [*] Initial Release  

# 1.1

* [*] API Authorization changes